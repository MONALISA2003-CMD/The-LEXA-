import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Activity, RefreshCw, Search } from 'lucide-react';
import { useWorkspace } from '../../app/WorkspaceContext';
import { apiPeopleProjects } from '../../data/remote/apiPeopleProjects';
import type { AuditEvent } from '../../data/contracts/people-projects';

function stamp(value: string): string {
  const date = new Date(value);
  return Number.isFinite(date.getTime()) ? new Intl.DateTimeFormat('en-UG', { dateStyle: 'medium', timeStyle: 'short' }).format(date) : 'Unknown date';
}

export default function AuditTrailPage() {
  const { workspace, branch } = useWorkspace();
  const [filter, setFilter] = useState('');
  const events = useQuery<AuditEvent[]>({
    queryKey: ['audit-events', workspace.id, branch.id, filter],
    queryFn: () => apiPeopleProjects.auditEvents(workspace.id, branch.id, { limit: 150, action: filter.trim() || undefined }),
    staleTime: 10_000,
  });
  return <div className="page-stack audit-trail-page">
    <div className="page-heading-row"><div><div className="eyebrow eyebrow-blue">CONTROL & ACCOUNTABILITY</div><h2>Audit trail</h2><p>Recorded changes for the selected workspace and branch, returned by the backend with the current user’s permissions.</p></div><button className="button button-secondary" onClick={() => void events.refetch()}><RefreshCw size={15}/> Refresh</button></div>
    <section className="section-card"><div className="table-toolbar"><div><h3>Activity history</h3><p>{events.data?.length ?? 0} matching events · newest first</p></div><label className="module-workspace-search"><Search size={16}/><input aria-label="Filter audit actions" value={filter} onChange={e => setFilter(e.target.value)} placeholder="Filter by action…"/></label></div>
      {events.isLoading && <div className="loading-state">Loading audit history…</div>}
      {events.isError && <div className="inline-error" role="alert"><strong>Audit history could not be loaded.</strong><span>{events.error instanceof Error ? events.error.message : 'Check your access and connection, then retry.'}</span><button className="button button-secondary button-small" onClick={() => void events.refetch()}>Retry</button></div>}
      {!events.isLoading && !events.isError && !(events.data?.length) && <div className="empty-state compact"><div className="empty-icon"><Activity size={22}/></div><h3>No audit events found</h3><p>Newly recorded workspace changes will appear here. Try another action filter.</p></div>}
      {!!events.data?.length && <div className="table-responsive"><table className="data-table"><thead><tr><th>WHEN</th><th>ACTOR</th><th>ACTION</th><th>RECORD</th><th>REQUEST ID</th></tr></thead><tbody>{events.data.map(event => <tr key={event.id}><td>{stamp(event.createdAt)}</td><td>{event.actorName || event.actorEmail || 'System'}</td><td><strong>{event.action}</strong></td><td>{event.resourceType}{event.resourceId ? ` · ${event.resourceId}` : ''}</td><td>{event.requestId || '—'}</td></tr>)}</tbody></table></div>}
    </section>
  </div>;
}
