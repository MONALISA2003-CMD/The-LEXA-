import { useQuery } from '@tanstack/react-query';
import type { ReactNode } from 'react';
import { Activity, Bot, CheckCircle2, Cloud, Database, Fingerprint, Mail, RefreshCw, ShieldCheck, Workflow, XCircle } from 'lucide-react';
import { useWorkspace } from '../../app/WorkspaceContext';
import { apiClient } from '../../data/remote/apiClient';
import { apiOperations, type OperationsOverview } from '../../data/remote/apiOperations';
import { isApiProvider } from '../../data/remote/runtimeConfig';
import { apiAuth, type SsoStatus } from '../../data/remote/apiAuth';

type IntelligenceStatus = { enabled: boolean; serviceConfigured: boolean; providersAvailable: string[]; availability: string; paidTierEnabled: boolean };
function fresh(value?: string | null) { if (!value) return false; const date = new Date(value); return Number.isFinite(date.getTime()) && Date.now() - date.getTime() < 120_000; }
function dateLabel(value?: string | null) { if (!value) return 'No heartbeat recorded'; const date = new Date(value); return Number.isFinite(date.getTime()) ? new Intl.DateTimeFormat('en-UG', { dateStyle: 'medium', timeStyle: 'short' }).format(date) : 'No heartbeat recorded'; }
function State({ ok, ready, label }: { ok: boolean; ready: boolean; label: string }) { const Icon = ok ? CheckCircle2 : XCircle; return <span className={`connections-state ${ok ? 'connections-state-ok' : 'connections-state-warn'}`}><Icon size={14}/>{label || (ready ? 'Ready' : 'Needs configuration')}</span>; }
function ConnectionCard({ title, detail, icon: Icon, children }: { title: string; detail: string; icon: any; children: ReactNode }) { return <article className="section-card connections-card"><div className="connections-card-heading"><span className="connections-icon"><Icon size={18}/></span><div><h3>{title}</h3><p>{detail}</p></div></div><div className="connections-card-body">{children}</div></article>; }
export default function ConnectionsPage() {
  const { workspace, branch } = useWorkspace();
  const overview = useQuery<OperationsOverview>({ queryKey: ['connections-operations', workspace.id, branch.id], queryFn: () => apiOperations.overview(workspace.id, branch.id), enabled: isApiProvider, refetchInterval: 30000, staleTime: 10000 });
  const sso = useQuery<SsoStatus>({ queryKey: ['connections-sso'], queryFn: () => apiAuth.ssoStatus(), enabled: isApiProvider, refetchInterval: 60000 });
  const ai = useQuery<IntelligenceStatus>({ queryKey: ['connections-ai', workspace.id, branch.id], queryFn: () => apiClient.get<IntelligenceStatus>(`/workspaces/${encodeURIComponent(workspace.id)}/branches/${encodeURIComponent(branch.id)}/intelligence/status`), enabled: isApiProvider, refetchInterval: 30000, staleTime: 10000 });
  const o = overview.data;
  const workerReady = fresh(o?.worker.lastHeartbeat);
  const providers = ai.data?.providersAvailable ?? [];
  return <div className="page-stack connections-page">
    <div className="page-heading-row"><div><div className="eyebrow eyebrow-blue">SERVICE CONNECTIONS</div><h2>Connections</h2><p>Live checks from the selected LEXA workspace and branch. A green state is shown only when the service reports it.</p></div><button className="button button-secondary" onClick={() => { void overview.refetch(); void sso.refetch(); void ai.refetch(); }}><RefreshCw size={15}/> Refresh</button></div>
    {!isApiProvider && <div className="overview-service-note"><Activity size={18}/><div><strong>Connect the LEXA backend to inspect services</strong><span>This screen uses the live API. Development-only browser data is not treated as a connected service.</span></div></div>}
    {isApiProvider && <div className="connections-grid">
      <ConnectionCard title="LEXA API" detail="Authenticated backend availability" icon={Activity}><State ok={o?.api.status === 'ok'} ready={Boolean(o)} label={o?.api.status ?? (overview.isLoading ? 'Checking' : 'Unavailable')}/><small>Checked {dateLabel(o?.checkedAt)}</small></ConnectionCard>
      <ConnectionCard title="PostgreSQL" detail="Production application database" icon={Database}><State ok={o?.database.status === 'ok'} ready={Boolean(o)} label={o?.database.status ?? (overview.isLoading ? 'Checking' : 'Unavailable')}/><small>Workspace-scoped reads and writes depend on the deployed restricted database role.</small></ConnectionCard>
      <ConnectionCard title="Background processing" detail="Queue consumer and scheduled work" icon={Workflow}><State ok={workerReady} ready={Boolean(o)} label={workerReady ? 'Worker heartbeat fresh' : 'Worker not live'}/><small>Last heartbeat: {dateLabel(o?.worker.lastHeartbeat)}</small><small>Redis: {o?.worker.redis ?? 'Unknown'} · ClamAV: {o?.worker.clamav ?? 'Unknown'}</small></ConnectionCard>
      <ConnectionCard title="Private file storage" detail="Cloudflare R2 object storage" icon={Cloud}><State ok={o?.worker.r2Configured === true} ready={Boolean(o)} label={o?.worker.r2Configured ? 'Credentials detected' : 'Credentials missing'}/><small>Bucket: lexa-private-platform-files</small><small>Credentials are never read back into this screen.</small></ConnectionCard>
      <ConnectionCard title="AI model routing" detail="Concurrent provider race; first valid response wins" icon={Bot}><State ok={Boolean(ai.data?.serviceConfigured && providers.length)} ready={Boolean(ai.data)} label={ai.data?.serviceConfigured ? `${providers.length} provider(s) configured` : ai.isLoading ? 'Checking' : 'No provider available'}/><small>{providers.length ? providers.join(' · ') : 'No configured provider is currently reported by the backend.'}</small><small>Paid-tier routing: {ai.data?.paidTierEnabled ? 'enabled' : 'disabled'}.</small></ConnectionCard>
      <ConnectionCard title="External identity sign-in" detail="OpenID Connect provider discovery and account linking" icon={Fingerprint}><State ok={sso.data?.enabled === true} ready={Boolean(sso.data)} label={sso.data?.enabled ? 'Provider settings present' : sso.isLoading ? 'Checking' : 'Not configured'}/><small>Provider: {sso.data?.issuerHost ?? 'Not configured'}</small><small>Callback: /api/v1/auth/sso/callback</small></ConnectionCard>
      <ConnectionCard title="Transactional email" detail="Notification delivery provider" icon={Mail}><State ok={Boolean(o && o.notifications.emailFailures === 0)} ready={Boolean(o)} label={o ? (o.notifications.emailFailures === 0 ? 'No delivery failures reported' : `${o.notifications.emailFailures} delivery issue(s)`) : 'Unknown'}/><small>Failures are monitored in the Operations Centre.</small></ConnectionCard>
      <ConnectionCard title="Tenant boundary" detail="Database row-level security coverage" icon={ShieldCheck}><State ok={o?.database.status === 'ok'} ready={Boolean(o)} label={o?.database.status === 'ok' ? 'Database reachable' : 'Verification required'}/><small>RLS policies are applied in PostgreSQL. Full enforcement is confirmed only after the API is running as lexa_app_runtime.</small></ConnectionCard>
    </div>}
    <section className="section-card connections-guidance"><div><h3>Secure setup details</h3><p>Never enter API keys or client secrets into a LEXA form or support message. Add credentials to the server’s secret settings and then refresh these checks.</p></div><ul><li>R2 needs a bucket-scoped Object Read & Write token.</li><li>OIDC needs an issuer, client ID, client secret, exact callback URL and a random state secret of at least 32 characters.</li><li>The continuously running queue consumer requires a paid Render worker service and a durable Redis-compatible queue connection.</li></ul></section>
  </div>;
}
