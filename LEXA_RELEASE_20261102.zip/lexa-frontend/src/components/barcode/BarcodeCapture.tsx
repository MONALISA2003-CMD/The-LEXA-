import { useEffect, useRef, useState } from 'react';
import { BrowserMultiFormatReader } from '@zxing/browser';
import { Barcode, Camera, Check, ImagePlus, Search, Square, X } from 'lucide-react';

type ScanControls = { stop: () => void };
const MAX_IMAGE_BYTES = 12 * 1024 * 1024;

export function BarcodeCapture({ onCode, label = 'Scan a barcode', compact = false, autoResolve = false }: {
  onCode: (code: string) => void | Promise<void>;
  label?: string;
  compact?: boolean;
  autoResolve?: boolean;
}) {
  const [code, setCode] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const controlsRef = useRef<ScanControls | null>(null);
  const readerRef = useRef<BrowserMultiFormatReader | null>(null);
  const mountedRef = useRef(true);
  const lastCodeRef = useRef('');

  function stopCamera() {
    controlsRef.current?.stop();
    controlsRef.current = null;
    readerRef.current = null;
    const stream = videoRef.current?.srcObject;
    if (typeof MediaStream !== 'undefined' && stream instanceof MediaStream) stream.getTracks().forEach((track) => track.stop());
    if (videoRef.current) videoRef.current.srcObject = null;
    setCameraActive(false);
  }

  async function submit(value = code) {
    const clean = value.trim();
    if (!clean) { setStatus('Enter or scan a barcode first.'); return; }
    setCode(clean);
    try {
      await onCode(clean);
      if (mountedRef.current) setStatus(`Code captured: ${clean}`);
    } catch (error) {
      if (mountedRef.current) setStatus(error instanceof Error ? `Could not process ${clean}: ${error.message}` : `Could not process ${clean}. Check the connection and try again.`);
      throw error;
    }
  }

  async function startCamera() {
    lastCodeRef.current = '';
    if (!navigator.mediaDevices?.getUserMedia || !window.isSecureContext) {
      setStatus('Camera scanning needs HTTPS and camera permission. You can use the image scanner or enter a code manually.');
      return;
    }
    if (!videoRef.current) { setStatus('The camera preview is not ready.'); return; }
    stopCamera();
    const reader = new BrowserMultiFormatReader();
    readerRef.current = reader;
    try {
      const controls = await reader.decodeFromVideoDevice(undefined, videoRef.current, (result) => {
        const detected = result?.getText().trim();
        if (!detected || detected === lastCodeRef.current) return;
        lastCodeRef.current = detected;
        stopCamera();
        void submit(detected).catch(() => undefined);
      });
      if (!mountedRef.current) { controls.stop(); return; }
      controlsRef.current = controls;
      setCameraActive(true);
      setStatus('Camera ready. Hold the code steady inside the frame.');
    } catch (error) {
      stopCamera();
      setStatus(error instanceof Error ? `Camera could not start: ${error.message}` : 'Camera could not start. Check browser permission and try again.');
    }
  }

  async function scanImage(file?: File) {
    if (!file) return;
    if (!file.type.startsWith('image/')) { setStatus('Choose an image file containing a QR code or barcode.'); return; }
    if (file.size > MAX_IMAGE_BYTES) { setStatus('Choose an image smaller than 12 MB.'); return; }
    setBusy(true); setStatus('Reading the image…');
    const url = URL.createObjectURL(file);
    try {
      const reader = new BrowserMultiFormatReader();
      const result = await reader.decodeFromImageUrl(url);
      const detected = result.getText().trim();
      if (!detected) throw new Error('No readable code was found in that image.');
      await submit(detected);
    } catch (error) {
      if (mountedRef.current) setStatus(error instanceof Error ? error.message : 'No readable QR code or barcode was found. Try a clearer image.');
    } finally {
      URL.revokeObjectURL(url);
      if (mountedRef.current) setBusy(false);
    }
  }

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      controlsRef.current?.stop();
      controlsRef.current = null;
      readerRef.current = null;
      const stream = videoRef.current?.srcObject;
      if (typeof MediaStream !== 'undefined' && stream instanceof MediaStream) stream.getTracks().forEach((track) => track.stop());
    };
  }, []);

  return <section className={`barcode-capture ${compact ? 'barcode-capture-compact' : ''}`} aria-label={label}>
    <div className="barcode-capture-controls">
      <label className="barcode-capture-input"><Barcode size={17} /><input value={code} onChange={(event) => setCode(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); void submit(); } }} placeholder="Scan or type barcode / SKU" aria-label="Barcode, SKU or product code" autoComplete="off" /><button type="button" className="barcode-capture-submit" onClick={() => void submit()}><Search size={15} /><span>{autoResolve ? 'Find' : 'Use code'}</span></button></label>
      <button type="button" className="button button-secondary button-small" disabled={cameraActive || busy} onClick={() => void startCamera()}><Camera size={15} /> Camera</button>
      <label className="button button-secondary button-small barcode-image-picker"><ImagePlus size={15} /> Image<input type="file" accept="image/*" aria-label="Choose barcode image" disabled={busy} onChange={(event) => { void scanImage(event.target.files?.[0]); event.currentTarget.value = ''; }} /></label>
      {cameraActive && <button type="button" className="button button-secondary button-small" onClick={stopCamera}><Square size={13} /> Stop</button>}
    </div>
    <div className={`barcode-camera-frame ${cameraActive ? 'barcode-camera-frame-active' : 'barcode-camera-frame-idle'}`} aria-hidden={!cameraActive}><video ref={videoRef} muted playsInline aria-label="Live barcode camera preview" />{cameraActive && <span className="barcode-camera-reticle" />}</div>
    {status && <div className="barcode-capture-status" role="status"><Check size={14} />{status}{cameraActive && <button type="button" aria-label="Close camera" onClick={stopCamera}><X size={14} /></button>}</div>}
  </section>;
}
