import { describe, expect, it, vi, afterEach } from 'vitest';
import { render, screen, fireEvent, waitFor, cleanup } from '@testing-library/react';
import { BarcodeCapture } from './BarcodeCapture';

const zxing = vi.hoisted(() => ({
  decodeFromImageUrl: vi.fn(async () => ({ getText: () => 'QR-IMG-456' })),
  decodeFromVideoDevice: vi.fn(async (_device: unknown, _video: unknown, callback: (result?: { getText(): string }) => void) => {
    callback({ getText: () => 'CAM-789' });
    return { stop: vi.fn() };
  }),
}));
vi.mock('@zxing/browser', () => ({
  BrowserMultiFormatReader: class {
    decodeFromImageUrl = zxing.decodeFromImageUrl;
    decodeFromVideoDevice = zxing.decodeFromVideoDevice;
  },
}));

afterEach(() => { cleanup(); vi.restoreAllMocks(); });

describe('BarcodeCapture', () => {
  it('submits an entered code without requiring camera support', async () => {
    const onCode = vi.fn();
    render(<BarcodeCapture onCode={onCode} />);
    fireEvent.change(screen.getByRole('textbox', { name: 'Barcode, SKU or product code' }), { target: { value: 'SKU-12345' } });
    fireEvent.click(screen.getByRole('button', { name: 'Use code' }));
    await waitFor(() => expect(onCode).toHaveBeenCalledWith('SKU-12345'));
  });

  it('keeps the video element mounted so camera streams can attach before activation', () => {
    render(<BarcodeCapture onCode={vi.fn()} />);
    expect(document.querySelector('.barcode-camera-frame video')).toBeInTheDocument();
  });

  it('decodes a QR/barcode from an uploaded image and submits the value', async () => {
    const onCode = vi.fn();
    Object.defineProperty(URL, 'createObjectURL', { configurable: true, value: vi.fn(() => 'blob:lexa-image') });
    Object.defineProperty(URL, 'revokeObjectURL', { configurable: true, value: vi.fn() });
    render(<BarcodeCapture onCode={onCode} />);
    const picker = screen.getByLabelText('Choose barcode image');
    fireEvent.change(picker, { target: { files: [new File(['image-data'], 'qr.png', { type: 'image/png' })] } });
    await waitFor(() => expect(onCode).toHaveBeenCalledWith('QR-IMG-456'));
    expect(zxing.decodeFromImageUrl).toHaveBeenCalledWith('blob:lexa-image');
  });

  it('rejects non-image uploads without calling the scanner', () => {
    const onCode = vi.fn();
    render(<BarcodeCapture onCode={onCode} />);
    fireEvent.change(screen.getByLabelText('Choose barcode image'), { target: { files: [new File(['not-image'], 'notes.txt', { type: 'text/plain' })] } });
    expect(screen.getByRole('status')).toHaveTextContent('Choose an image file containing a QR code or barcode.');
    expect(onCode).not.toHaveBeenCalled();
    expect(zxing.decodeFromImageUrl).not.toHaveBeenCalled();
  });

  it('does not submit an empty code', () => {
    const onCode = vi.fn();
    render(<BarcodeCapture onCode={onCode} />);
    fireEvent.click(screen.getByRole('button', { name: 'Use code' }));
    expect(onCode).not.toHaveBeenCalled();
    expect(screen.getByRole('status')).toHaveTextContent('Enter or scan a barcode first.');
  });
});
