import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const router = readFileSync(resolve(root, 'src/app/router.tsx'), 'utf8');
const catalog = readFileSync(resolve(root, 'src/modules/operations/moduleCatalog.ts'), 'utf8');
const required = [
  ["modules", "OperationsWorkspacePage"],
  ["modules/integrations", "ConnectionsPage"],
  ["modules/audit", "AuditTrailPage"],
];
for (const [path, component] of required) {
  const line = router.split('\n').find(value => value.includes(`path: '${path}'`) || value.includes(`path: '/${path}'`));
  if (!line || !line.includes(component)) throw new Error(`Required route ${path} must resolve to ${component}.`);
  if (line.includes('Navigate to="/"')) throw new Error(`Required route ${path} must not terminate at the dashboard.`);
}
const moduleIds = [...catalog.matchAll(/\bid:\s*'([^']+)'/g)].map(match => match[1]);
if (moduleIds.length < 40) throw new Error(`Expected a populated module catalogue; found ${moduleIds.length}.`);
if (!router.includes("path: 'modules/:moduleId'")) throw new Error('Missing module detail route.');
console.log(`Module navigation check passed: ${moduleIds.length} catalogue entries plus directory, integrations and audit routes.`);
