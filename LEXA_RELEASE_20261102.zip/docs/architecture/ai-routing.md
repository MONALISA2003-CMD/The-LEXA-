# LEXA AI routing

## Runtime design

The assistant uses the native TypeScript `AiRouterService` inside the existing NestJS API:

```text
LEXA web application → Render NestJS API → concurrent provider race → first valid model response
```

The API keeps provider credentials server-side, verifies the session and workspace/branch permissions, builds a permission-filtered aggregate context, applies provider timeouts/cooldowns, and records usage metadata. The model has no SQL, database, browser, shell or business-write tools.

## Concurrent provider routing

When eligible credentials are configured, LEXA launches requests concurrently to the configured free/developer routes: Gemini, Groq, OpenRouter (`openrouter/free`) and NVIDIA NIM. `Promise.any` returns the first successful, valid completion; the router then aborts remaining requests. Provider-specific cooldowns prevent repeatedly selecting a quota-exhausted or unavailable endpoint. The caller can cap parallelism, timeouts and output-token limits through server configuration.

This is **race-to-first-valid**, not an ensemble: it does not wait for every provider or merge their answers. Parallel requests improve tail latency when providers respond at different speeds, but the slowest providers may still receive a request and count usage before cancellation arrives. Provider availability, model identifiers, privacy terms and free quotas can change. Paid provider routing remains disabled while `LEXA_AI_PAID_TIER_ENABLED=false`; `OPENAI_API_KEY` and paid Gemini credentials are not part of the free fan-out.

## Data boundary

The assistant receives only permission-filtered business aggregates. It must not receive raw customer or employee profiles, contact details, salaries, credentials, attachments or document contents. Provider prompts and completions are not stored in the LEXA usage ledger; request metadata, provider/model, tokens, latency and status are recorded.

## Operational controls

Keep all provider keys in Render's private environment. Confirm billing mode and privacy terms for each provider before enabling it. Rotate or disable a provider when its quota is exhausted, model is withdrawn, or terms no longer meet the data policy. Verify all configured provider/model combinations and perform authorised workspace smoke tests after deployment. Do not mark AI healthy merely because environment variables are present; a successful authenticated model response is the readiness check.
