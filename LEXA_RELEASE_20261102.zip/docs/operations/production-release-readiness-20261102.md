# LEXA production release readiness — 2 November 2026

## Scope

This release source prepares tenant isolation, concurrent AI routing, generic OpenID Connect SSO, background processing, private object storage, module navigation fixes and stricter event handling. MRR/ARR configuration and reporting were intentionally left untouched.

## Verified in this work

- Production Neon row-level-security policy migration was applied to 26 previously missing or non-forced tenant tables. A temporary clone verified tenant A could read only its own project and a cross-tenant update changed zero rows. Earlier clone tests confirmed cross-tenant insert rejection.
- Production catalog inspection now shows 145 tables with `tenant_id`: 143 have RLS enabled and forced. The two deliberately unforced webhook routing/evidence tables are `notification_email_webhook_events` and `notification_email_webhook_routes`; the webhook must verify provider signature and resolve tenant routing before setting tenant context. Their pre-tenant access path remains a specific security review item.
- The restricted database role `lexa_app_runtime` exists with `NOLOGIN` and `BYPASSRLS=false`; `lexa_app` is a member. Render now has `DATABASE_RUNTIME_ROLE=lexa_app_runtime` and `LEXA_REQUIRE_RUNTIME_ROLE=true`, and the API redeploy triggered by this environment change reached `live` (`dep-dbk3cd8ae00c73fndd30`). The previous source build started successfully with the runtime-role URL option. The stronger startup assertion and coverage of all schema delegates arrive with the source ZIP; the currently live source does not yet include those latest changes, so do not treat application-layer tenant verification as complete until that package is imported and acceptance tests pass.
- Live Render checks after the role change: `/health/live` returned HTTP 200; `/health/ready` returned HTTP 503. The 503 is a confirmed blocker, not a green result. A direct production transaction using `SET ROLE lexa_app_runtime` confirmed `current_user=lexa_app_runtime`, `BYPASSRLS=false`, `SELECT 1` works and tenant-scoped table queries execute. The currently deployed source hides the underlying Prisma readiness error. The release ZIP now changes Prisma context-setting calls to `$queryRaw` and logs a redacted readiness diagnostic so the next deployment can expose and resolve the exact issue.
- Tenant-context Prisma wrapper coverage passes for all 66 schema models.
- Backend unit/contract tests: 84 passed, 0 failed.
- OpenAPI coverage: 296 operations across 235 routes, no missing or orphan operations.
- Route-to-adapter coverage: 18 backend-backed domain adapters.
- Ledger coverage: 9 source workflows, idempotency/balance invariants and branch checks.
- Frontend navigation static check: 54 module catalogue entries plus directory, integrations and audit routes.
- Repository validator and `render.yaml` YAML parse pass.
- Core business transaction tables inspected in production (sales, sale lines/payments, stock movements, AR/AP invoices/payments, purchase/sales orders, product rows, HR, projects, support and module records) had zero business rows in the inspected tenant. No destructive deletion was performed.

## Source changes included

- Sales and purchasing paths continue to post their transactional effects in authoritative backend transactions: stock movement/reservations, receivables/payables, cash and balanced ledger postings where applicable, audit and durable domain events. The outbox now refuses to acknowledge unknown event types as processed.
- Worker code is prepared for queue-backed attachment scanning, outbox delivery, email notifications, recurring invoicing, retention and operational alert evaluation, with retries, idempotency and graceful shutdown.
- Private R2 integration is prepared for bucket `lexa-private-platform-files`.
- Generic OIDC controller uses discovery, PKCE, state/nonce validation, JWKS signature checking and only links verified emails to existing LEXA users. It is disabled until an identity-provider configuration is supplied.
- AI routing starts eligible free/developer models concurrently and returns the first valid response; it is not an answer-ensemble. Paid routing remains disabled.
- Frontend repairs include module directory, connections and audit routes; ZXing camera/image/manual barcode scanning support; SSO sign-in affordance when configured.

## Not yet live / release blockers

1. **Source release:** the GitHub connector denied repository write access. This package has not been uploaded to GitHub, and Render/Vercel still run the previous source commit. The release ZIP must be imported into the connected repository before those services build the new code.
2. **Application-layer tenant proof and readiness:** Render has now been switched to `DATABASE_RUNTIME_ROLE=lexa_app_runtime` and the API restart is live, but `/health/ready` is 503 (while `/health/live` is 200). The older running source has incomplete Prisma tenant-context wrapping, so affected older HR/project delegates fail closed under RLS until the new source is imported. After import, verify startup reports `lexa_app_runtime` with `BYPASSRLS=false`, ensure `/health/ready` returns 200, and rerun API-level tenant A/B read/write tests.
3. **Background worker:** `render.yaml` defines `lexa-platform-worker` on the paid `starter` plan. The worker has not been created/synced; continuous background workers are not available on the existing free API plan. Existing `lexa-redis` is free/in-memory (not durable through restarts), so use a durable Key Value broker before production queue workload. Do not create paid resources without owner cost approval.
4. **R2 credentials:** bucket and account are known, but the Cloudflare connector cannot mint R2 S3 credentials because it lacks API-token provisioning scope. Create a bucket-scoped R2 Object Read & Write token and set `R2_ACCESS_KEY_ID` and `R2_SECRET_ACCESS_KEY` directly in Render secrets for API and worker. Never send secrets in chat.
5. **External SSO:** generic OIDC code is implemented but no provider was selected/configured. Set issuer URL, client ID/secret, exact callback URL, and a random state secret of at least 32 characters in Render. Register `https://lexa-backend-api-live.onrender.com/api/v1/auth/sso/callback` with the chosen provider. Only use verified existing LEXA accounts; no tenant/user auto-provisioning is enabled.
6. **Frontend verification:** frontend dependency installation, browser tests, typecheck and production build were not completed in this environment. CI must complete them after import. The ZXing scanner tests are included but not yet executed here.
7. **Module completeness:** LEXA has 54 module catalogue entries. Dedicated workflows cover core sales, inventory, purchasing, receivables/payables, ledger, tax, team access, people/payroll/projects/support and commerce flows. Some secondary module register screens still use `module_records` and are not yet full domain-specific transactional workflows. They must not be represented as completely production-ready until their API/database behaviour and cross-module side effects have been individually implemented and tested.

## Seed/demo data review

No generic `module_records`, products, sales, purchase orders, inventory movements, AR/AP transactions, employees, projects, support cases or attachments were found in the production tenant during the inspection. Existing accounting setup consists of 85 accounting periods and 20 ledger accounts, plus one audit event. These are treated as business configuration/system history rather than conclusively identified demo transactions and have been preserved. No production rows were deleted.

## Required secret configuration (Render)

- `R2_ACCOUNT_ID=fd30d011f3df62adac89458dbe45de90`
- `R2_BUCKET=lexa-private-platform-files`
- `R2_ACCESS_KEY_ID` and `R2_SECRET_ACCESS_KEY` (bucket-scoped R2 API token)
- `OIDC_ISSUER_URL`, `OIDC_CLIENT_ID`, `OIDC_CLIENT_SECRET`, `OIDC_REDIRECT_URI`, `OIDC_STATE_SECRET` (32+ random chars)
- For worker: `REDIS_URL`, `WORKER_DATABASE_URL`, `WORKER_TENANT_DATABASE_URL`; R2 credentials above.
- AI: eligible provider keys `GEMINI_FREE_API_KEY`, `GROQ_API_KEY`, `OPENROUTER_API_KEY`, `NVIDIA_NIM_API_KEY`. Only configure keys for models, quotas and terms approved by the account owner.

## Release acceptance checks

After import and all secrets/resources are set, require:

- GitHub CI green including backend tests, frontend tests/typecheck/build, Prisma validation/migration deploy, RLS verification and ledger coverage.
- Render API and worker healthy; worker heartbeat present and advancing; queue depths drain; ClamAV and R2 upload → quarantine → clean download path verified.
- API DB role confirmed as `lexa_app_runtime` with `BYPASSRLS=false`; tenant A/B read, update and insert isolation tests rerun against deployed API.
- SSO start/callback smoke test using the selected real IdP and a verified pre-existing user.
- Authenticated AI prompt returns a real response and records model/latency metadata; confirm parallel model fan-out is not rate-limiting the caller.
- Cross-module acceptance tests for sale, stock receipt, supplier purchase, customer invoice/payment, supplier bill/payment and delivery; each must verify source transaction, stock/cash/AR/AP/GL, domain event and downstream notifications as applicable.
- Business-module screen inventory completed; generic records disabled for any workflow that requires authoritative domain posting.

No MRR/ARR code, plan price or billing calculation was changed by this work.
