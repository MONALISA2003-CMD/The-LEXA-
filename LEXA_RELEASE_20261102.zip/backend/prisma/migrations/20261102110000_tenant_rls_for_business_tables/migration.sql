-- Extend forced tenant RLS to the remaining tenant-owned operational and SaaS tables.
-- This migration changes policy/permissions only; it does not modify business rows.

ALTER TABLE public."commerce_delivery_agents" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."commerce_delivery_agents" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "commerce_delivery_agents_tenant_scope" ON public."commerce_delivery_agents";
CREATE POLICY "commerce_delivery_agents_tenant_scope" ON public."commerce_delivery_agents" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."commerce_delivery_agents" TO lexa_app_runtime;

ALTER TABLE public."commerce_delivery_collection_lines" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."commerce_delivery_collection_lines" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "commerce_delivery_collection_lines_tenant_scope" ON public."commerce_delivery_collection_lines";
CREATE POLICY "commerce_delivery_collection_lines_tenant_scope" ON public."commerce_delivery_collection_lines" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."commerce_delivery_collection_lines" TO lexa_app_runtime;

ALTER TABLE public."commerce_delivery_collection_reports" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."commerce_delivery_collection_reports" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "commerce_delivery_collection_reports_tenant_scope" ON public."commerce_delivery_collection_reports";
CREATE POLICY "commerce_delivery_collection_reports_tenant_scope" ON public."commerce_delivery_collection_reports" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."commerce_delivery_collection_reports" TO lexa_app_runtime;

ALTER TABLE public."commerce_delivery_events" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."commerce_delivery_events" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "commerce_delivery_events_tenant_scope" ON public."commerce_delivery_events";
CREATE POLICY "commerce_delivery_events_tenant_scope" ON public."commerce_delivery_events" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."commerce_delivery_events" TO lexa_app_runtime;

ALTER TABLE public."commerce_delivery_items" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."commerce_delivery_items" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "commerce_delivery_items_tenant_scope" ON public."commerce_delivery_items";
CREATE POLICY "commerce_delivery_items_tenant_scope" ON public."commerce_delivery_items" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."commerce_delivery_items" TO lexa_app_runtime;

ALTER TABLE public."commerce_delivery_remittance_allocations" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."commerce_delivery_remittance_allocations" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "commerce_delivery_remittance_allocations_tenant_scope" ON public."commerce_delivery_remittance_allocations";
CREATE POLICY "commerce_delivery_remittance_allocations_tenant_scope" ON public."commerce_delivery_remittance_allocations" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."commerce_delivery_remittance_allocations" TO lexa_app_runtime;

ALTER TABLE public."commerce_delivery_remittances" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."commerce_delivery_remittances" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "commerce_delivery_remittances_tenant_scope" ON public."commerce_delivery_remittances";
CREATE POLICY "commerce_delivery_remittances_tenant_scope" ON public."commerce_delivery_remittances" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."commerce_delivery_remittances" TO lexa_app_runtime;

ALTER TABLE public."hr_attendance" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."hr_attendance" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "hr_attendance_tenant_scope" ON public."hr_attendance";
CREATE POLICY "hr_attendance_tenant_scope" ON public."hr_attendance" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."hr_attendance" TO lexa_app_runtime;

ALTER TABLE public."hr_employee_compensation" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."hr_employee_compensation" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "hr_employee_compensation_tenant_scope" ON public."hr_employee_compensation";
CREATE POLICY "hr_employee_compensation_tenant_scope" ON public."hr_employee_compensation" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."hr_employee_compensation" TO lexa_app_runtime;

ALTER TABLE public."hr_employee_shift_assignments" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."hr_employee_shift_assignments" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "hr_employee_shift_assignments_tenant_scope" ON public."hr_employee_shift_assignments";
CREATE POLICY "hr_employee_shift_assignments_tenant_scope" ON public."hr_employee_shift_assignments" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."hr_employee_shift_assignments" TO lexa_app_runtime;

ALTER TABLE public."hr_employees" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."hr_employees" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "hr_employees_tenant_scope" ON public."hr_employees";
CREATE POLICY "hr_employees_tenant_scope" ON public."hr_employees" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."hr_employees" TO lexa_app_runtime;

ALTER TABLE public."hr_leave_requests" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."hr_leave_requests" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "hr_leave_requests_tenant_scope" ON public."hr_leave_requests";
CREATE POLICY "hr_leave_requests_tenant_scope" ON public."hr_leave_requests" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."hr_leave_requests" TO lexa_app_runtime;

ALTER TABLE public."hr_payroll_deductions" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."hr_payroll_deductions" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "hr_payroll_deductions_tenant_scope" ON public."hr_payroll_deductions";
CREATE POLICY "hr_payroll_deductions_tenant_scope" ON public."hr_payroll_deductions" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."hr_payroll_deductions" TO lexa_app_runtime;

ALTER TABLE public."hr_payroll_lines" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."hr_payroll_lines" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "hr_payroll_lines_tenant_scope" ON public."hr_payroll_lines";
CREATE POLICY "hr_payroll_lines_tenant_scope" ON public."hr_payroll_lines" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."hr_payroll_lines" TO lexa_app_runtime;

ALTER TABLE public."hr_payroll_runs" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."hr_payroll_runs" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "hr_payroll_runs_tenant_scope" ON public."hr_payroll_runs";
CREATE POLICY "hr_payroll_runs_tenant_scope" ON public."hr_payroll_runs" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."hr_payroll_runs" TO lexa_app_runtime;

ALTER TABLE public."hr_shifts" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."hr_shifts" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "hr_shifts_tenant_scope" ON public."hr_shifts";
CREATE POLICY "hr_shifts_tenant_scope" ON public."hr_shifts" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."hr_shifts" TO lexa_app_runtime;

ALTER TABLE public."hr_timesheets" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."hr_timesheets" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "hr_timesheets_tenant_scope" ON public."hr_timesheets";
CREATE POLICY "hr_timesheets_tenant_scope" ON public."hr_timesheets" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."hr_timesheets" TO lexa_app_runtime;

ALTER TABLE public."project_cost_entries" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."project_cost_entries" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "project_cost_entries_tenant_scope" ON public."project_cost_entries";
CREATE POLICY "project_cost_entries_tenant_scope" ON public."project_cost_entries" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."project_cost_entries" TO lexa_app_runtime;

ALTER TABLE public."project_tasks" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."project_tasks" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "project_tasks_tenant_scope" ON public."project_tasks";
CREATE POLICY "project_tasks_tenant_scope" ON public."project_tasks" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."project_tasks" TO lexa_app_runtime;

ALTER TABLE public."projects" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."projects" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "projects_tenant_scope" ON public."projects";
CREATE POLICY "projects_tenant_scope" ON public."projects" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."projects" TO lexa_app_runtime;

ALTER TABLE public."support_cases" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."support_cases" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "support_cases_tenant_scope" ON public."support_cases";
CREATE POLICY "support_cases_tenant_scope" ON public."support_cases" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."support_cases" TO lexa_app_runtime;

ALTER TABLE public."ai_usage_events" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."ai_usage_events" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "ai_usage_events_tenant_scope" ON public."ai_usage_events";
CREATE POLICY "ai_usage_events_tenant_scope" ON public."ai_usage_events" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."ai_usage_events" TO lexa_app_runtime;

ALTER TABLE public."tenant_feature_overrides" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."tenant_feature_overrides" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "tenant_feature_overrides_tenant_scope" ON public."tenant_feature_overrides";
CREATE POLICY "tenant_feature_overrides_tenant_scope" ON public."tenant_feature_overrides" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."tenant_feature_overrides" TO lexa_app_runtime;

ALTER TABLE public."tenant_subscriptions" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."tenant_subscriptions" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "tenant_subscriptions_tenant_scope" ON public."tenant_subscriptions";
CREATE POLICY "tenant_subscriptions_tenant_scope" ON public."tenant_subscriptions" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."tenant_subscriptions" TO lexa_app_runtime;

ALTER TABLE public."tenant_support_access_audit" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."tenant_support_access_audit" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "tenant_support_access_audit_tenant_scope" ON public."tenant_support_access_audit";
CREATE POLICY "tenant_support_access_audit_tenant_scope" ON public."tenant_support_access_audit" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."tenant_support_access_audit" TO lexa_app_runtime;

ALTER TABLE public."tenant_usage_counters" ENABLE ROW LEVEL SECURITY;
ALTER TABLE public."tenant_usage_counters" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "tenant_usage_counters_tenant_scope" ON public."tenant_usage_counters";
CREATE POLICY "tenant_usage_counters_tenant_scope" ON public."tenant_usage_counters" USING (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), '')) WITH CHECK (tenant_id::text = NULLIF(current_setting('app.tenant_id', true), ''));
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public."tenant_usage_counters" TO lexa_app_runtime;
