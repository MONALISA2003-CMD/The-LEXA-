-- Verified external identity links for generic OpenID Connect SSO.
-- Only existing invited/registered users can be linked; this does not auto-provision tenants or access.
CREATE TABLE IF NOT EXISTS public.external_identities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_key text NOT NULL,
  subject text NOT NULL,
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_authenticated_at timestamptz,
  CONSTRAINT external_identities_provider_subject_key UNIQUE(provider_key, subject),
  CONSTRAINT external_identities_provider_user_key UNIQUE(provider_key, user_id)
);
CREATE INDEX IF NOT EXISTS external_identities_user_id_idx ON public.external_identities(user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.external_identities TO lexa_app_runtime;
