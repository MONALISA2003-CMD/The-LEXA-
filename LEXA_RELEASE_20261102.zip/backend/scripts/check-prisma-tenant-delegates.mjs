import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
const here = dirname(fileURLToPath(import.meta.url));
const schema = readFileSync(resolve(here, '../prisma/schema.prisma'), 'utf8');
const service = readFileSync(resolve(here, '../src/prisma/prisma.service.ts'), 'utf8');
const models = [...schema.matchAll(/^model\s+(\w+)\s*\{/gm)].map((match) => match[1]);
const delegateBlock = service.match(/const MODEL_DELEGATES = new Set\(\[([\s\S]*?)\]\);/)?.[1] ?? '';
const delegates = new Set([...delegateBlock.matchAll(/['\"]([a-z][A-Za-z0-9]*)['\"]/g)].map((match) => match[1]));
const toDelegate = (model) => model[0].toLowerCase() + model.slice(1);
const missing = models.map(toDelegate).filter((name) => !delegates.has(name));
if (missing.length) {
  console.error(`Tenant-context Prisma delegates missing (${missing.length}): ${missing.join(', ')}`);
  process.exit(1);
}
console.log(`Tenant-context delegate coverage passed: ${models.length}/${models.length} Prisma models.`);
