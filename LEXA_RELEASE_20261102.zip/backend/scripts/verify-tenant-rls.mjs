import { Pool } from 'pg';
const connectionString = process.env.DATABASE_URL;
if (!connectionString) throw new Error('DATABASE_URL is required.');
const pool = new Pool({ connectionString, max: 1, connectionTimeoutMillis: 8000 });
try {
  const role = await pool.query(`SELECT current_user AS role_name, r.rolbypassrls AS bypass_rls
    FROM pg_roles r WHERE r.rolname = current_user`);
  if (role.rows[0]?.role_name !== 'lexa_app_runtime' || role.rows[0]?.bypass_rls !== false) {
    throw new Error(`Expected lexa_app_runtime with BYPASSRLS=false; received ${JSON.stringify(role.rows[0] ?? null)}`);
  }
  const coverage = await pool.query(`SELECT count(*)::int AS tenant_tables,
      count(*) FILTER (WHERE c.relrowsecurity AND c.relforcerowsecurity)::int AS forced_tables,
      count(*) FILTER (WHERE NOT c.relrowsecurity OR NOT c.relforcerowsecurity)::int AS gaps
    FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
    WHERE n.nspname='public' AND c.relkind='r'
      AND EXISTS (SELECT 1 FROM information_schema.columns ic
        WHERE ic.table_schema='public' AND ic.table_name=c.relname AND ic.column_name='tenant_id')`);
  const row = coverage.rows[0];
  if (row.gaps !== 0 || row.tenant_tables !== row.forced_tables) {
    throw new Error(`Tenant RLS coverage incomplete: ${JSON.stringify(row)}`);
  }
  console.log(`Tenant RLS passed: ${row.forced_tables}/${row.tenant_tables} tenant tables use ENABLE + FORCE RLS; runtime role is restricted.`);
} finally {
  await pool.end();
}
