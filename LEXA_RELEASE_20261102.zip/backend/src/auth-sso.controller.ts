import {
  BadRequestException, Controller, ForbiddenException, Get, Query, Req, Res,
  ServiceUnavailableException, UnauthorizedException,
} from '@nestjs/common';
import type { FastifyReply, FastifyRequest } from 'fastify';
import { createHash, createHmac, createPublicKey, randomBytes, timingSafeEqual, verify as verifySignature } from 'node:crypto';
import { PrismaService } from './prisma/prisma.service';

type OidcMetadata = { issuer: string; authorization_endpoint: string; token_endpoint: string; jwks_uri: string };
type StatePayload = { state: string; nonce: string; verifier: string; returnTo: string; issuedAt: number };
function env(name: string): string { return (process.env[name] ?? '').trim(); }
function sha256(value: string): string { return createHash('sha256').update(value).digest('hex'); }
function cookieValue(header: string | undefined, name: string): string | undefined {
  for (const part of (header ?? '').split(';')) {
    const index = part.indexOf('=');
    if (index < 0 || part.slice(0, index).trim() !== name) continue;
    try { return decodeURIComponent(part.slice(index + 1).trim()); } catch { return undefined; }
  }
  return undefined;
}
function b64json(value: string): any {
  try { return JSON.parse(Buffer.from(value, 'base64url').toString('utf8')); }
  catch { throw new UnauthorizedException('The identity provider returned an invalid token.'); }
}

@Controller('auth/sso')
export class ExternalSsoController {
  private metadataCache: OidcMetadata | undefined;
  private metadataExpiresAt = 0;
  private jwksCache: { expiresAt: number; keys: any[] } | undefined;

  constructor(private readonly prisma: PrismaService) {}

  private config() {
    const issuer = env('OIDC_ISSUER_URL').replace(/\/$/, '');
    const clientId = env('OIDC_CLIENT_ID');
    const clientSecret = env('OIDC_CLIENT_SECRET');
    const redirectUri = env('OIDC_REDIRECT_URI');
    const stateSecret = env('OIDC_STATE_SECRET');
    const frontend = env('LEXA_FRONTEND_URL') || 'https://lexareview.vercel.app';
    if (!issuer || !clientId || !clientSecret || !redirectUri || stateSecret.length < 32) {
      throw new ServiceUnavailableException({ code: 'SSO_NOT_CONFIGURED', message: 'External sign-in has not been configured by the administrator.' });
    }
    const issuerUrl = new URL(issuer);
    const redirect = new URL(redirectUri);
    if ((issuerUrl.protocol !== 'https:' && issuerUrl.hostname !== 'localhost') || redirect.protocol !== 'https:') {
      throw new ServiceUnavailableException('SSO requires HTTPS issuer and callback URLs.');
    }
    return { issuer, clientId, clientSecret, redirectUri, stateSecret, frontend };
  }

  private async metadata(): Promise<OidcMetadata> {
    if (this.metadataCache && this.metadataExpiresAt > Date.now()) return this.metadataCache;
    const { issuer } = this.config();
    const response = await fetch(`${issuer}/.well-known/openid-configuration`, { signal: AbortSignal.timeout(7000) });
    if (!response.ok) throw new ServiceUnavailableException('The identity provider discovery endpoint is unavailable.');
    const value = await response.json() as OidcMetadata;
    if (value.issuer.replace(/\/+$/, '') !== issuer || !value.authorization_endpoint || !value.token_endpoint || !value.jwks_uri) {
      throw new ServiceUnavailableException('The identity provider discovery document is incomplete or has an unexpected issuer.');
    }
    for (const endpoint of [value.authorization_endpoint, value.token_endpoint, value.jwks_uri]) {
      if (new URL(endpoint).protocol !== 'https:') throw new ServiceUnavailableException('The identity provider advertised a non-HTTPS endpoint.');
    }
    this.metadataCache = value;
    this.metadataExpiresAt = Date.now() + 5 * 60_000;
    return value;
  }

  private signState(payload: StatePayload, secret: string): string {
    const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
    const signature = createHmac('sha256', secret).update(body).digest('base64url');
    return `${body}.${signature}`;
  }

  private readState(value: string | undefined, secret: string): StatePayload {
    if (!value) throw new UnauthorizedException('SSO state is missing. Restart sign-in.');
    const [body, signature] = value.split('.');
    if (!body || !signature) throw new UnauthorizedException('SSO state is invalid. Restart sign-in.');
    const expected = createHmac('sha256', secret).update(body).digest();
    let actual: Buffer;
    try { actual = Buffer.from(signature, 'base64url'); } catch { throw new UnauthorizedException('SSO state is invalid.'); }
    if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) throw new UnauthorizedException('SSO state signature is invalid.');
    const payload = b64json(body) as StatePayload;
    if (!payload.state || !payload.nonce || !payload.verifier || !Number.isFinite(payload.issuedAt) || Date.now() - payload.issuedAt > 10 * 60_000 || payload.issuedAt > Date.now() + 30_000) {
      throw new UnauthorizedException('SSO state has expired. Restart sign-in.');
    }
    return payload;
  }

  private stateCookie(reply: FastifyReply, value: string, maxAge: number): void {
    reply.header('Set-Cookie', `lexa_oidc_state=${encodeURIComponent(value)}; Path=/api/v1/auth/sso; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`);
  }

  private redirectFailure(reply: FastifyReply, frontend: string, reason: string): FastifyReply {
    const url = new URL('/login', frontend);
    url.searchParams.set('sso', 'failed');
    url.searchParams.set('reason', reason);
    reply.header('Set-Cookie', [
      'lexa_oidc_state=; Path=/api/v1/auth/sso; HttpOnly; Secure; SameSite=Lax; Max-Age=0',
      'lexa_session=; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=0',
    ]);
    return reply.redirect(url.toString());
  }

  @Get('status')
  status() {
    const configured = Boolean(env('OIDC_ISSUER_URL') && env('OIDC_CLIENT_ID') && env('OIDC_CLIENT_SECRET') && env('OIDC_REDIRECT_URI') && env('OIDC_STATE_SECRET').length >= 32);
    let issuerHost: string | undefined;
    try { issuerHost = env('OIDC_ISSUER_URL') ? new URL(env('OIDC_ISSUER_URL')).host : undefined; } catch { /* omit malformed settings */ }
    return { enabled: configured, protocol: 'OpenID Connect', issuerHost, startUrl: configured ? '/auth/sso/start' : null };
  }

  @Get('start')
  async start(@Query('returnTo') returnTo: string | undefined, @Res() reply: FastifyReply): Promise<FastifyReply> {
    const cfg = this.config();
    const metadata = await this.metadata();
    const safeReturn = typeof returnTo === 'string' && returnTo.startsWith('/') && !returnTo.startsWith('//') && !returnTo.includes('\\') ? returnTo.slice(0, 300) : '/';
    const state: StatePayload = {
      state: randomBytes(32).toString('base64url'), nonce: randomBytes(32).toString('base64url'),
      verifier: randomBytes(32).toString('base64url'), returnTo: safeReturn, issuedAt: Date.now(),
    };
    this.stateCookie(reply, this.signState(state, cfg.stateSecret), 600);
    const challenge = createHash('sha256').update(state.verifier).digest('base64url');
    const url = new URL(metadata.authorization_endpoint);
    url.searchParams.set('client_id', cfg.clientId);
    url.searchParams.set('redirect_uri', cfg.redirectUri);
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('scope', env('OIDC_SCOPES') || 'openid email profile');
    url.searchParams.set('state', state.state);
    url.searchParams.set('nonce', state.nonce);
    url.searchParams.set('code_challenge', challenge);
    url.searchParams.set('code_challenge_method', 'S256');
    return reply.redirect(url.toString());
  }

  private async validateIdToken(token: string, expectedNonce: string, metadata: OidcMetadata, clientId: string): Promise<any> {
    const parts = token.split('.');
    if (parts.length !== 3) throw new UnauthorizedException('The identity provider returned a malformed ID token.');
    const header = b64json(parts[0]);
    const claims = b64json(parts[1]);
    if (header.alg !== 'RS256' || typeof header.kid !== 'string') throw new UnauthorizedException('The identity provider used an unsupported signing algorithm.');
    if (!this.jwksCache || this.jwksCache.expiresAt <= Date.now()) {
      const response = await fetch(metadata.jwks_uri, { signal: AbortSignal.timeout(7000) });
      if (!response.ok) throw new ServiceUnavailableException('The identity provider signing keys are unavailable.');
      const jwks = await response.json() as { keys?: any[] };
      this.jwksCache = { keys: Array.isArray(jwks.keys) ? jwks.keys : [], expiresAt: Date.now() + 5 * 60_000 };
    }
    const jwk = this.jwksCache.keys.find((key) => key.kid === header.kid && key.kty === 'RSA' && key.use !== 'enc');
    if (!jwk) { this.jwksCache = undefined; throw new UnauthorizedException('The identity provider signing key was not recognised.'); }
    const publicKey = createPublicKey({ key: jwk, format: 'jwk' });
    const valid = verifySignature('RSA-SHA256', Buffer.from(`${parts[0]}.${parts[1]}`), publicKey, Buffer.from(parts[2], 'base64url'));
    if (!valid) throw new UnauthorizedException('The identity provider ID token signature is invalid.');
    const now = Math.floor(Date.now() / 1000);
    const audiences = Array.isArray(claims.aud) ? claims.aud : [claims.aud];
    if (claims.iss !== metadata.issuer || !audiences.includes(clientId) || (audiences.length > 1 && claims.azp !== clientId) || !Number.isFinite(claims.exp) || claims.exp <= now || !Number.isFinite(claims.iat) || claims.iat > now + 300 || claims.nonce !== expectedNonce || typeof claims.sub !== 'string' || !claims.sub) {
      throw new UnauthorizedException('The identity provider ID token failed issuer, audience, time, nonce, or subject validation.');
    }
    return claims;
  }

  @Get('callback')
  async callback(
    @Query('state') state: string | undefined,
    @Query('code') code: string | undefined,
    @Query('error') providerError: string | undefined,
    @Req() request: FastifyRequest,
    @Res() reply: FastifyReply,
  ): Promise<FastifyReply> {
    const frontend = env('LEXA_FRONTEND_URL') || 'https://lexareview.vercel.app';
    try {
      if (providerError) return this.redirectFailure(reply, frontend, 'provider_denied');
      if (!state || !code || code.length > 4096) throw new BadRequestException('The identity provider did not return a valid authorization code.');
      const cfg = this.config();
      const cookie = cookieValue(request.headers.cookie, 'lexa_oidc_state');
      const payload = this.readState(cookie, cfg.stateSecret);
      if (state !== payload.state) throw new UnauthorizedException('SSO state does not match. Restart sign-in.');
      const metadata = await this.metadata();
      const body = new URLSearchParams({ grant_type: 'authorization_code', code, redirect_uri: cfg.redirectUri, client_id: cfg.clientId, code_verifier: payload.verifier });
      const headers: Record<string, string> = { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' };
      if ((env('OIDC_TOKEN_AUTH_METHOD') || 'client_secret_post') === 'client_secret_basic') {
        headers.Authorization = `Basic ${Buffer.from(`${cfg.clientId}:${cfg.clientSecret}`).toString('base64')}`;
      } else body.set('client_secret', cfg.clientSecret);
      const tokenResponse = await fetch(metadata.token_endpoint, { method: 'POST', headers, body, signal: AbortSignal.timeout(9000) });
      const tokenPayload = await tokenResponse.json().catch(() => null) as any;
      if (!tokenResponse.ok || typeof tokenPayload?.id_token !== 'string') throw new UnauthorizedException('The identity provider token exchange failed.');
      const claims = await this.validateIdToken(tokenPayload.id_token, payload.nonce, metadata, cfg.clientId);
      if (claims.email_verified !== true || typeof claims.email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(claims.email)) {
        throw new ForbiddenException('Use a verified email address that is already registered in LEXA.');
      }
      const providerKey = env('OIDC_PROVIDER_KEY') || new URL(cfg.issuer).host;
      let identity = await this.prisma.externalIdentity.findUnique({ where: { providerKey_subject: { providerKey, subject: claims.sub } }, select: { userId: true } });
      if (!identity) {
        const user = await this.prisma.user.findUnique({ where: { email: claims.email.toLowerCase() }, select: { id: true } });
        if (!user) throw new ForbiddenException('This verified identity is not linked to a LEXA account. Ask a workspace administrator for an invitation.');
        identity = await this.prisma.externalIdentity.upsert({
          where: { providerKey_subject: { providerKey, subject: claims.sub } },
          create: { providerKey, subject: claims.sub, userId: user.id, email: claims.email.toLowerCase(), lastAuthenticatedAt: new Date() },
          update: { email: claims.email.toLowerCase(), lastAuthenticatedAt: new Date() },
          select: { userId: true },
        });
      } else {
        await this.prisma.externalIdentity.update({ where: { providerKey_subject: { providerKey, subject: claims.sub } }, data: { email: claims.email.toLowerCase(), lastAuthenticatedAt: new Date() } });
      }
      const sessionToken = randomBytes(32).toString('base64url');
      await this.prisma.session.create({ data: { userId: identity.userId, tokenHash: sha256(sessionToken), expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) } });
      const target = new URL(payload.returnTo, cfg.frontend);
      target.searchParams.set('sso', 'success');
      reply.header('Set-Cookie', [
        'lexa_oidc_state=; Path=/api/v1/auth/sso; HttpOnly; Secure; SameSite=Lax; Max-Age=0',
        `lexa_session=${encodeURIComponent(sessionToken)}; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=${7 * 24 * 60 * 60}`,
      ]);
      return reply.redirect(target.toString());
    } catch (error) {
      const safeReason = error instanceof ForbiddenException ? 'account_not_linked' : error instanceof ServiceUnavailableException ? 'provider_unavailable' : 'sign_in_failed';
      return this.redirectFailure(reply, frontend, safeReason);
    }
  }
}
