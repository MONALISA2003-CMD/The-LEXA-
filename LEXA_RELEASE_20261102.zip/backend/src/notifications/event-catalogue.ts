export type NotificationChannel = 'in_app' | 'email';

export interface NotificationDefinition {
  title: string;
  body: string;
  audienceRoles: readonly string[];
  entityModule?: string;
  hrefBase?: string;
  emailTemplate: 'business_event';
}

const ADMIN = ['owner', 'owner_administrator', 'administrator', 'admin'];
const MANAGERS = [...ADMIN, 'business_manager', 'manager', 'branch_manager'];
const FINANCE = [...MANAGERS, 'accountant', 'payroll_officer'];
const SALES = [...MANAGERS, 'sales', 'sales_operator', 'cashier'];
const DELIVERY = [...MANAGERS, 'inventory_operator', 'warehouse_operator'];

/** Versioned, intentionally non-PII notification text. Never copy raw event payloads into inbox/email. */
export const NOTIFICATION_CATALOGUE: Readonly<Record<string, NotificationDefinition>> = {
  'sale.completed': { title: 'Sale completed', body: 'A sale was completed. Open the sale to review its details.', audienceRoles: SALES, entityModule: 'sales', hrefBase: '/sales/' , emailTemplate: 'business_event' },
  'sale.payment.received': { title: 'Payment receipt recorded', body: 'A customer payment was recorded. Review the sale and its balance.', audienceRoles: [...new Set([...SALES, ...FINANCE])], entityModule: 'sales', hrefBase: '/sales/', emailTemplate: 'business_event' },
  'sale.payment.direct_receipt_recorded': { title: 'Payment receipt recorded', body: 'A direct customer receipt was recorded. Review the related sale.', audienceRoles: FINANCE, entityModule: 'sales', hrefBase: '/sales/', emailTemplate: 'business_event' },
  'customer_invoice.issued': { title: 'Customer invoice issued', body: 'A customer invoice was issued. Review its due date and outstanding balance.', audienceRoles: FINANCE, entityModule: 'sales-invoices', hrefBase: '/modules/sales-invoices', emailTemplate: 'business_event' },
  'customer_invoice.receipt_allocated': { title: 'Invoice receipt allocated', body: 'A customer receipt was allocated to an invoice. Review the receivables register.', audienceRoles: FINANCE, entityModule: 'sales-invoices', hrefBase: '/modules/sales-invoices', emailTemplate: 'business_event' },
  'customer.credit.created': { title: 'Customer credit created', body: 'A customer credit balance was created. Review the receivables register.', audienceRoles: FINANCE, entityModule: 'sales-invoices', hrefBase: '/modules/sales-invoices', emailTemplate: 'business_event' },
  'customer.credit.changed': { title: 'Customer credit changed', body: 'A customer credit balance changed. Review the receivables register.', audienceRoles: FINANCE, entityModule: 'sales-invoices', hrefBase: '/modules/sales-invoices', emailTemplate: 'business_event' },
  'customer.payment.overdue': { title: 'Customer payment overdue', body: 'A customer invoice is overdue. Review the receivables register.', audienceRoles: FINANCE, entityModule: 'sales-invoices', hrefBase: '/modules/sales-invoices', emailTemplate: 'business_event' },
  'customer.payment.reminder_due': { title: 'Customer payment reminder due', body: 'A customer payment reminder is due. Review the receivables register.', audienceRoles: FINANCE, entityModule: 'sales-invoices', hrefBase: '/modules/sales-invoices', emailTemplate: 'business_event' },
  'sale.return.recorded': { title: 'Refund or reversal recorded', body: 'A sale return or reversal was recorded. Review the sale and its accounting.', audienceRoles: FINANCE, entityModule: 'sales', hrefBase: '/sales/', emailTemplate: 'business_event' },
  'delivery.dispatch.created': { title: 'Delivery assigned', body: 'A delivery was assigned. Review the delivery workflow.', audienceRoles: DELIVERY, entityModule: 'deliveries', hrefBase: '/modules/deliveries', emailTemplate: 'business_event' },
  'delivery.lifecycle.changed': { title: 'Delivery status changed', body: 'A delivery status changed. Review the delivery workflow.', audienceRoles: DELIVERY, entityModule: 'deliveries', hrefBase: '/modules/deliveries', emailTemplate: 'business_event' },
  'delivery.picked_up': { title: 'Delivery picked up', body: 'A delivery was picked up. Review the delivery workflow.', audienceRoles: DELIVERY, entityModule: 'deliveries', hrefBase: '/modules/deliveries', emailTemplate: 'business_event' },
  'delivery.delivered': { title: 'Delivery completed', body: 'A delivery was marked delivered. Review the delivery workflow.', audienceRoles: DELIVERY, entityModule: 'deliveries', hrefBase: '/modules/deliveries', emailTemplate: 'business_event' },
  'delivery.failed': { title: 'Delivery failed or returned', body: 'A delivery failed or was returned. Review the delivery workflow.', audienceRoles: DELIVERY, entityModule: 'deliveries', hrefBase: '/modules/deliveries', emailTemplate: 'business_event' },
  'delivery.status_changed': { title: 'Delivery status changed', body: 'A delivery status changed. Review the delivery workflow.', audienceRoles: DELIVERY, entityModule: 'deliveries', hrefBase: '/modules/deliveries', emailTemplate: 'business_event' },
  'delivery.remittance.allocated': { title: 'Rider remittance allocated', body: 'A rider remittance was allocated to a sale. Review the remittance workflow.', audienceRoles: FINANCE, entityModule: 'deliveries', hrefBase: '/modules/deliveries', emailTemplate: 'business_event' },
  'customer.created_from_lead': { title: 'Customer created from lead', body: 'A lead was converted into a customer. Review the customer record.', audienceRoles: SALES, entityModule: 'customers', hrefBase: '/modules/customers', emailTemplate: 'business_event' },
  'delivery.collection.reported': { title: 'Rider collection reported', body: 'A rider collection was reported. Review the remittance workflow.', audienceRoles: FINANCE, entityModule: 'deliveries', hrefBase: '/modules/deliveries', emailTemplate: 'business_event' },
  'delivery.remittance.accepted': { title: 'Rider remittance received', body: 'A rider remittance was received or reconciled. Review the remittance workflow.', audienceRoles: FINANCE, entityModule: 'deliveries', hrefBase: '/modules/deliveries', emailTemplate: 'business_event' },
  'import.preview.completed': { title: 'Import validation completed', body: 'An import preview completed. Review validation results before applying it.', audienceRoles: ADMIN, entityModule: 'data-operations', hrefBase: '/data-operations', emailTemplate: 'business_event' },
  'import.approved': { title: 'Import approved', body: 'An import was approved and is ready to apply.', audienceRoles: ADMIN, entityModule: 'data-operations', hrefBase: '/data-operations', emailTemplate: 'business_event' },
  'import.applied': { title: 'Import applied', body: 'An import was applied. Review its results.', audienceRoles: ADMIN, entityModule: 'data-operations', hrefBase: '/data-operations', emailTemplate: 'business_event' },
  'import.failed': { title: 'Import failed', body: 'An import failed. Review the Operations Centre before retrying.', audienceRoles: ADMIN, entityModule: 'data-operations', hrefBase: '/data-operations', emailTemplate: 'business_event' },
  'export.completed': { title: 'Export completed', body: 'An export completed and is ready for authorised download.', audienceRoles: ADMIN, entityModule: 'data-operations', hrefBase: '/data-operations', emailTemplate: 'business_event' },
  'export.failed': { title: 'Export failed', body: 'An export failed. Review the Operations Centre before retrying.', audienceRoles: ADMIN, entityModule: 'data-operations', hrefBase: '/data-operations', emailTemplate: 'business_event' },
  'backup.completed': { title: 'Backup completed', body: 'A backup completed. Review its manifest and retention state.', audienceRoles: ADMIN, entityModule: 'operations', hrefBase: '/business-tools', emailTemplate: 'business_event' },
  'backup.failed': { title: 'Backup failed', body: 'A backup failed. Review the Operations Centre and backup runbook.', audienceRoles: ADMIN, entityModule: 'operations', hrefBase: '/business-tools', emailTemplate: 'business_event' },
  'restore.completed': { title: 'Restore completed', body: 'A restore completed and is awaiting the required recovery review.', audienceRoles: ADMIN, entityModule: 'operations', hrefBase: '/business-tools', emailTemplate: 'business_event' },
  'restore.failed': { title: 'Restore failed', body: 'A restore failed. Keep outbound work paused and review the restore runbook.', audienceRoles: ADMIN, entityModule: 'operations', hrefBase: '/business-tools', emailTemplate: 'business_event' },
  'recurring_invoice.generated': { title: 'Recurring invoice generated', body: 'A recurring invoice occurrence was generated. Review the invoice.', audienceRoles: FINANCE, entityModule: 'sales-invoices', hrefBase: '/modules/sales-invoices', emailTemplate: 'business_event' },
  'recurring_invoice.failed': { title: 'Recurring invoice generation failed', body: 'A recurring invoice could not be generated. Review the schedule and occurrence history.', audienceRoles: FINANCE, entityModule: 'recurring-invoices', hrefBase: '/modules/recurring-invoices', emailTemplate: 'business_event' },
  'attachment.scan.clean': { title: 'Attachment scan completed', body: 'An attachment passed the security scan and is available to authorised users.', audienceRoles: MANAGERS, entityModule: 'inbox', hrefBase: '/inbox', emailTemplate: 'business_event' },
  'attachment.scan.quarantined': { title: 'Attachment quarantined', body: 'An attachment was quarantined by the security scanner. Review it before taking action.', audienceRoles: ADMIN, entityModule: 'inbox', hrefBase: '/inbox', emailTemplate: 'business_event' },
  'attachment.scan.failed': { title: 'Attachment scan failed', body: 'An attachment could not be scanned. It remains unavailable until reviewed.', audienceRoles: ADMIN, entityModule: 'inbox', hrefBase: '/inbox', emailTemplate: 'business_event' },
  'worker.queue.incident': { title: 'Background worker incident', body: 'A background worker or queue incident requires operator attention.', audienceRoles: ADMIN, entityModule: 'operations', hrefBase: '/business-tools', emailTemplate: 'business_event' },
  'goods_receipt.posted': { title: 'Goods receipt posted', body: 'Goods were received against a purchase order. Review inventory and the supplier commitment.', audienceRoles: [...new Set([...DELIVERY, ...FINANCE])], entityModule: 'procurement', hrefBase: '/modules/procurement', emailTemplate: 'business_event' },
  'procurement.goods_receipt.posted': { title: 'Goods receipt posted', body: 'A procurement receipt was posted. Review accepted and rejected quantities.', audienceRoles: [...new Set([...DELIVERY, ...FINANCE])], entityModule: 'procurement', hrefBase: '/modules/procurement', emailTemplate: 'business_event' },
  'purchase_order.created': { title: 'Purchase order created', body: 'A purchase order was created. Review supplier, items and approval requirements.', audienceRoles: FINANCE, entityModule: 'procurement', hrefBase: '/modules/procurement', emailTemplate: 'business_event' },
  'purchase_order.ordered': { title: 'Purchase order issued', body: 'A purchase order was issued to a supplier. Track its expected delivery.', audienceRoles: FINANCE, entityModule: 'procurement', hrefBase: '/modules/procurement', emailTemplate: 'business_event' },
  'sales_order.created': { title: 'Sales order created', body: 'A sales order was created. Review availability and fulfilment requirements.', audienceRoles: SALES, entityModule: 'sales-orders', hrefBase: '/modules/sales-orders', emailTemplate: 'business_event' },
  'sales_order.confirmed': { title: 'Sales order confirmed', body: 'A sales order was confirmed. Inventory reservation and fulfilment can proceed.', audienceRoles: SALES, entityModule: 'sales-orders', hrefBase: '/modules/sales-orders', emailTemplate: 'business_event' },
  'sales_order.fulfilled': { title: 'Sales order fulfilled', body: 'A sales order was fulfilled. Review the linked sale and dispatch.', audienceRoles: [...new Set([...SALES, ...DELIVERY])], entityModule: 'sales-orders', hrefBase: '/modules/sales-orders', emailTemplate: 'business_event' },
  'inventory.movement.created': { title: 'Inventory movement recorded', body: 'Stock changed in a warehouse or branch. Review the movement and resulting balance.', audienceRoles: DELIVERY, entityModule: 'inventory', hrefBase: '/modules/inventory', emailTemplate: 'business_event' },
  'inventory.stock_count.posted': { title: 'Stock count posted', body: 'A verified stock count was posted and inventory balances were adjusted.', audienceRoles: DELIVERY, entityModule: 'inventory', hrefBase: '/modules/inventory', emailTemplate: 'business_event' },
  'ledger.journal.posted': { title: 'Journal posted', body: 'A financial journal was posted. Review the source document and account balances.', audienceRoles: FINANCE, entityModule: 'general-ledger', hrefBase: '/modules/general-ledger', emailTemplate: 'business_event' },
  'supplier_invoice.approved': { title: 'Supplier invoice approved', body: 'A supplier invoice was approved and is ready for payment processing.', audienceRoles: FINANCE, entityModule: 'purchase-invoices', hrefBase: '/modules/purchase-invoices', emailTemplate: 'business_event' },
  'supplier_payment.recorded': { title: 'Supplier payment recorded', body: 'A supplier payment was recorded. Review allocations and the remaining balance.', audienceRoles: FINANCE, entityModule: 'purchase-invoices', hrefBase: '/modules/purchase-invoices', emailTemplate: 'business_event' },
  'people.payroll.calculated': { title: 'Payroll calculated', body: 'A payroll calculation completed. Review totals and approvals before posting.', audienceRoles: FINANCE, entityModule: 'payroll', hrefBase: '/modules/payroll', emailTemplate: 'business_event' },
  'people.payroll.submitted': { title: 'Payroll submitted', body: 'A payroll run was submitted for approval or payment processing.', audienceRoles: FINANCE, entityModule: 'payroll', hrefBase: '/modules/payroll', emailTemplate: 'business_event' },
  'manufacturing.work_order.completed': { title: 'Work order completed', body: 'A manufacturing work order was completed. Review output, material use and quality results.', audienceRoles: [...new Set([...DELIVERY, ...FINANCE])], entityModule: 'manufacturing', hrefBase: '/modules/manufacturing', emailTemplate: 'business_event' },
  'quality.inspection.created': { title: 'Quality inspection created', body: 'A quality inspection is ready for assessment and disposition.', audienceRoles: DELIVERY, entityModule: 'quality', hrefBase: '/modules/quality', emailTemplate: 'business_event' },

};

export function notificationHref(eventType: string, recordId: unknown): string | undefined {
  const definition = NOTIFICATION_CATALOGUE[eventType];
  if (!definition?.hrefBase) return undefined;
  if (definition.hrefBase.endsWith('/')) {
    const id = typeof recordId === 'string' ? recordId : '';
    return /^[0-9a-f-]{16,64}$/i.test(id) ? `${definition.hrefBase}${encodeURIComponent(id)}` : definition.hrefBase.slice(0, -1);
  }
  return definition.hrefBase;
}

export function isKnownNotificationEvent(eventType: string): boolean {
  return Object.prototype.hasOwnProperty.call(NOTIFICATION_CATALOGUE, eventType);
}
