import { ServiceUnavailableException } from '@nestjs/common';
function escapeHtml(value: string): string { return value.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!); }
export async function sendTransactionalEmail(input: { to: string; subject: string; text: string; actionUrl: string; actionLabel: string; html?: string; idempotencyKey?: string }): Promise<void> {
  // The public demo may NEVER send real external email, even if a key is accidentally configured.
  if (process.env.LEXA_RUNTIME_MODE === 'demo') throw new ServiceUnavailableException({ code: 'DEMO_EXTERNAL_EMAIL_DISABLED', message: 'Sending external email is disabled in the interactive demonstration.' });
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESEND_FROM_EMAIL;
  if (!apiKey || !from) throw new ServiceUnavailableException({ code: 'EMAIL_DELIVERY_NOT_CONFIGURED', message: 'Set RESEND_API_KEY and RESEND_FROM_EMAIL in the API environment.' });
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST', headers: { authorization: `Bearer ${apiKey}`, 'content-type': 'application/json', ...(input.idempotencyKey ? { 'Idempotency-Key': input.idempotencyKey } : {}) },
    body: JSON.stringify({ from, to: [input.to], subject: input.subject, text: input.text,
      html: input.html ?? `<div style="font-family:Arial,sans-serif;line-height:1.6;color:#152033"><div style="background:#06132f;padding:18px 24px"><img src="https://lexaaamaal.com/lexa-master-lockup-light.png" alt="LEXA" width="174" height="48" style="display:block;width:174px;max-width:100%;height:auto;border:0"></div><p>${escapeHtml(input.text).replace(/\n/g,'<br>')}</p><p><a href="${escapeHtml(input.actionUrl)}" style="display:inline-block;padding:12px 18px;background:#163a72;color:#fff;text-decoration:none;border-radius:6px">${escapeHtml(input.actionLabel)}</a></p><p style="color:#667085;font-size:12px">If you did not request this message, ignore it.</p><p style="color:#667085;font-size:11px">LEXA is a subsidiary of AMAAL GROUP.</p></div>` }),
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) throw new ServiceUnavailableException({ code: 'EMAIL_DELIVERY_FAILED', message: `Resend rejected the email request (${response.status}).` });
}
