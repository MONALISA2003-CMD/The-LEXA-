# Deployment guide

## Frontend — Vercel

- Project: `lexa_review`
- Root directory: `lexa-frontend`
- Framework: Vite
- Build command: `npm run build`
- Output directory: `dist`
- API rewrites: `lexa-frontend/vercel.json` routes API traffic to the existing Render service.

## Backend — Render

- Service: `lexa-backend-api-live`
- Runtime: Docker
- Dockerfile: `backend/Dockerfile`
- Docker context: repository root
- Region: Frankfurt
- Desired web-service plan: Starter (`0.5 CPU / 512 MB`)

Keep the existing service. Merge environment-variable changes into its private settings; never replace all variables with a partial list. The checked-in `render.yaml` describes the desired service tier but does not prove that the connected service was upgraded.

## Database — Neon

- Project: `lexa-backend`
- Production branch: `production`
- Database: `lexa`
- Application login role: `lexa_app`
- Least-privilege runtime role: `lexa_app_runtime`

Use the Neon pooled connection URL without a startup `options=-c role=...` parameter. The Prisma service applies `DATABASE_RUNTIME_ROLE` transaction-locally after the connection has been acquired.

## Migration safety

Production migrations are immutable history. Apply reviewed forward migrations only through the approved release process. Do not rename or edit an applied migration directory, do not run `prisma migrate dev` against production, and do not run concurrent migration processes from multiple service instances.
