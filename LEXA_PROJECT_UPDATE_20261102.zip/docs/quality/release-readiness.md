# LEXA release readiness and live infrastructure status

**Snapshot date:** 2 November 2026 (Kampala time)  
**Repository:** `MONALISA2003-CMD/The-LEXA-`  
**Branch:** `main`  
**Inspected source commit:** `131f986f05bef8ae62c0b3c7df514bb9ba714d18`

This record is a point-in-time inspection. The archive was built from the clean source bundle available in this conversation, then reconciled against the current GitHub main-branch layout and connected provider state. It is not a byte-for-byte export of current main. The included Neon pooler correction is a source patch in this archive; it has not been merged to GitHub or deployed to Render.

## Current source change in this archive

The connected backend logs showed Prisma error `P2039`: Neon rejected `options=-c role=lexa_app_runtime` as an unsupported startup parameter. The included `backend/src/prisma/prisma.service.ts` leaves the pooled `DATABASE_URL` unchanged and applies `set_config('role', runtimeRole, true)` inside each interactive Prisma transaction before applying tenant/user context. The runtime role is identifier-validated before use.

A read-only transaction test against the production branch confirmed that `lexa_app` is a member of `lexa_app_runtime`, that transaction-local role switching changes `current_user` to `lexa_app_runtime`, and that the runtime role can use the required schema and read the tenant/membership tables. This test did not change schema or application data.

## Neon — live observed state

- Project: `lexa-backend` (`empty-mud-76816448`), Frankfurt (`aws-eu-central-1`), PostgreSQL 17.
- Production branch: `production` (`br-snowy-hill-ba5a9ggc`), state `ready`.
- Database: `lexa`.
- Login role: `lexa_app`; member of `lexa_app_runtime`.
- The project endpoint configuration reported 0.25 CU minimum and maximum, with `suspend_timeout_seconds=0` (scale-to-zero disabled at inspection).
- The production branch reported approximately 42 MB logical size and 2.35 MB cumulative data transfer in the returned usage snapshot.
- No database reset, schema edit, migration, seed or business-data write was performed during this inspection.

The connected project response did not expose its paid/free billing-plan label. Confirm billing tier and monthly allowance directly in Neon before assuming a particular quota.

## Render — live observed state

- Service: `lexa-backend-api-live` (`srv-dbhp0f0m7kps73ffeqrg`), Frankfurt, one instance.
- URL: `https://lexa-backend-api-live.onrender.com`.
- Dockerfile: `backend/Dockerfile`, context `.`; branch `main`; auto-deploy on commit.
- The service API currently reported `plan=free`. The `render.yaml` in this archive targets `plan=starter` for the desired $7 paid web-service tier, but that file does not itself upgrade the connected live service. The connected Render tool did not expose an in-place plan-update action during this inspection.
- The configured Render `healthCheckPath` was blank.
- Recent idle metrics showed roughly 197–241 MiB memory use and very low CPU. Request/latency metrics were not returned, so this is not a 25–50 user load test.
- `GET /health/live` returned HTTP 200. `GET /health/ready` returned HTTP 503 because the database check failed.
- Logs at 2 November 2026 19:24 UTC showed Prisma `P2039` / PostgreSQL `08P01` from the unsupported startup `role` parameter.

After applying this archive through a reviewed release path, set Render's health check to `/health/ready`, confirm `DATABASE_RUNTIME_ROLE=lexa_app_runtime`, and ensure the `DATABASE_URL` has no startup role option. Then redeploy and verify readiness before inviting users.

## Vercel — live observed state

- Project: `lexa_review` (`prj_Pdbd6sJ3yPB80hMvwATxuOeS57KE`), framework Vite.
- Latest production deployment at inspection: `READY`, commit `131f986f05bef8ae62c0b3c7df514bb9ba714d18`.
- Deployment URL: `lexareview-3fdr8kmnb-kabuusumohammed182-7875s-projects.vercel.app`.
- Custom alias listed by the project: `lexareview.vercel.app`.
- Project root remains `lexa-frontend`; build output remains `dist`.

A Vercel `READY` deployment does not prove that the Render API is database-ready. The frontend/API integration still needs a signed-in smoke test after backend readiness becomes green.

## GitHub and deployment boundary

- The inspected GitHub `main` head was `131f986f05bef8ae62c0b3c7df514bb9ba714d18`.
- GitHub write operations from the connected integration were rejected with HTTP 403 (`Resource not accessible by integration`). No code was pushed or merged by this task.
- Render and Vercel were not changed by this archive operation. No new production deployment was triggered.
- The source archive includes the Neon correction, but the connected main branch and live Render image still need that correction applied and deployed.

## Release gates still open

1. Apply/review the source patch, commit it through an authorised GitHub workflow, then deploy the same reviewed commit to Render.
2. Change the actual Render service from Free to Starter in Render Dashboard and verify the service API reports the paid plan. The archive's `render.yaml` states the intended plan only.
3. Set Render health check to `/health/ready`; verify `/health/live` 200 and `/health/ready` 200 after deploy.
4. Confirm the actual Neon plan/usage limits and monitor compute-hours. The project endpoint snapshot showed 0.25 CU min/max; it is not yet configured for the earlier suggested 1–2 CU autoscaling range.
5. Sign in and smoke-test workspace reads, sales, inventory, finance, reports, role-based access and an approved backup/restore staging flow.
6. Load-test 25–50 concurrent users using realistic sales, inventory, finance and report workflows. Do not claim this low-cost setup is lag-free until the test and production metrics support it.

**Validation limit:** this archive was structurally checked and ZIP integrity-tested after creation. Full dependency installation, backend/frontend test suites and production deployment have not been run from this archive in this environment.
