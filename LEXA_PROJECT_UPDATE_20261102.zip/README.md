# LEXA

LEXA is a multi-tenant business management platform for sales, inventory, finance, procurement, people operations, reporting and administration.

## Architecture

```text
.
├── backend/                  # NestJS API, Prisma schema, migrations and tests
├── lexa-frontend/            # React + TypeScript + Vite web application
├── docs/                     # Architecture, security, deployment and operations guidance
├── scripts/                  # Repository cleanup and validation
├── .github/workflows/        # CI and repository-maintenance workflows
└── render.yaml               # Existing Render API service configuration
```

There is one active backend and one active frontend. The AI router runs inside the NestJS API. A worker entry point is retained in the backend package, but no separate worker or Python intelligence service is part of the current connected deployment.

## Local development

Use Node.js 22 (`.nvmrc`).

**Frontend**

```bash
cd lexa-frontend
npm install
npm run build
```

**Backend**

```bash
cd backend
cp .env.example .env
# Set a development-only database URL. Never use production credentials locally.
npm install
npm test
npm run build
```

## Connected deployment topology (inspected 2 November 2026)

- **Frontend:** Vercel project `lexa_review`, root directory `lexa-frontend`, framework Vite, output `dist`.
- **API:** existing Render service `lexa-backend-api-live`, Dockerfile `backend/Dockerfile`, repository-root Docker context, Frankfurt region.
- **Database:** Neon PostgreSQL project `lexa-backend`, production branch `production`, database `lexa`.
- **AI:** native TypeScript router inside the backend API; provider credentials remain in Render private environment settings.

See `docs/quality/release-readiness.md` for the exact observed deployment status, open issues and validation limits. The source configuration targets Render Starter; the connected service must be checked in the Render dashboard because the API still reported its live plan as Free during the inspection.

## Data and migration safety

- Neon PostgreSQL is the system of record.
- Prisma migration directory names are immutable once applied. Do not rename, reorder, edit, remove or reset applied migrations.
- Add schema changes only as reviewed forward migrations. Never run `prisma migrate dev` against production.
- Never commit live `.env` files, database URLs, provider keys, bootstrap secrets or backup-encryption keys.
- Frontend `VITE_*` values are public browser configuration, never secrets.

## Validation

- Repository layout: `python3 scripts/validate_repository.py`
- Frontend: `cd lexa-frontend && npm install && npm run build`
- Backend: `cd backend && npm install && npm test && npm run build`
- Operations: `docs/operations/runbooks/`
