#!/usr/bin/env python3
"""Validate LEXA's single-root repository layout."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "backend/package.json",
    "lexa-frontend/package.json",
    "lexa-frontend/vercel.json",
    "render.yaml",
    ".github/workflows/backend-ci.yml",
]
FORBIDDEN_COPIES = [
    "The-LEXA",
    "The-LEXA--main",
    "LEXA_WS8_updated",
]
errors = []
for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        errors.append(f"Missing canonical project file: {rel}")
for rel in FORBIDDEN_COPIES:
    if (ROOT / rel).exists():
        errors.append(f"Duplicate nested repository found: {rel}/")
for rel in [
    "LEXA_Render_Current_Fix",
    "LEXA_Render_TS2339_Fix",
    "LEXA_Render_Vercel_Build_Repairs_20261031",
    "LEXA_Workstream4_Reviewed_Patch",
    "LEXA_Workstreams_0_3_Patch",
    "increment-5",
]:
    if (ROOT / rel).exists():
        errors.append(f"Unarchived patch bundle found: {rel}/")
for p in ROOT.rglob("*.zip"):
    if ".git" not in p.parts:
        errors.append(f"Downloaded archive must not be committed: {p.relative_to(ROOT)}")
for p in ROOT.rglob("node_modules"):
    if ".git" not in p.parts:
        errors.append(f"Dependency directory must not be committed: {p.relative_to(ROOT)}")
if errors:
    print("LEXA repository layout check failed:")
    for item in errors:
        print(f" - {item}")
    sys.exit(1)
print("LEXA repository layout is canonical: one frontend, one backend, no nested repository copies.")
