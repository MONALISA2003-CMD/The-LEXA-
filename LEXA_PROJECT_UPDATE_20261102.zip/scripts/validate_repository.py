#!/usr/bin/env python3
"""Validate LEXA's canonical roots, secrets hygiene and production migrations."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = (
    "README.md", ".nvmrc", ".gitignore", ".dockerignore", "render.yaml",
    "REPOSITORY_LAYOUT_MANIFEST.json", "backend/package.json", "backend/Dockerfile",
    "backend/prisma/schema.prisma", "lexa-frontend/package.json", "lexa-frontend/vercel.json",
    "scripts/clean_repository.py", "scripts/validate_repository.py",
    "docs/architecture/backend-architecture.md", "docs/deployment/deployment-guide.md",
    "docs/operations/runbooks/README.md", "docs/quality/release-readiness.md",
)
errors = [f"Missing required file: {item}" for item in REQUIRED if not (ROOT / item).is_file()]
for folder in ("services", "deploy", "node_modules", "dist", "coverage", ".vercel"):
    if (ROOT / folder).exists(): errors.append(f"Unexpected or generated root directory: {folder}/")
package_files = sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob("package.json") if not any(part in {"node_modules", "dist", "coverage"} for part in p.parts))
if package_files != ["backend/package.json", "lexa-frontend/package.json"]:
    errors.append(f"Expected exactly two application manifests; found {package_files}")
for p in ROOT.rglob("*"):
    if ".git" in p.parts: continue
    if p.is_symlink(): errors.append(f"Symlink not allowed: {p.relative_to(ROOT)}"); continue
    if not p.is_file(): continue
    rel = p.relative_to(ROOT).as_posix()
    if p.suffix.lower() in {".zip", ".pyc"}: errors.append(f"Nested/generated archive not allowed: {rel}")
    if p.name.startswith(".env") and p.name not in {".env.example", ".env.worker.example"}:
        errors.append(f"Potential live secret file: {rel}")
# Historical API/module identifiers remain intentionally intact for compatibility. Documentation filenames are kept professional.
legacy_doc_names = re.compile(r"(^|[-_.])(phase|workstream|increment|patch)(?:[0-9]+)?([-_.]|$)", re.I)
for p in (ROOT / "docs").rglob("*"):
    if p.is_file() and legacy_doc_names.search(p.stem): errors.append(f"Legacy stage label in documentation filename: {p.relative_to(ROOT)}")
if (ROOT / "backend/prisma/migrations").is_dir():
    dirs = [p for p in (ROOT / "backend/prisma/migrations").iterdir() if p.is_dir()]
    if len(dirs) != 30: errors.append(f"Expected 30 preserved Prisma migrations; found {len(dirs)}")
else: errors.append("Missing Prisma migrations directory")
if errors:
    print("Repository validation failed:")
    for error in errors: print(" - " + error)
    raise SystemExit(1)
print("Repository validation passed: canonical application roots, two package manifests, 30 preserved migrations and no live secrets or nested archives.")
