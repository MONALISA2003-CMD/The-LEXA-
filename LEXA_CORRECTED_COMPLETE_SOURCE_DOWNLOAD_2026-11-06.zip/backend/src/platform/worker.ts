import 'dotenv/config';
import '../observability';
import { randomUUID, createHash } from 'node:crypto';
import { Pool } from 'pg';
import { Queue, Worker } from 'bullmq';
import { S3Client, GetObjectCommand, CopyObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { scanWithClamAV, pingClamAV, InfectedFileError } from './clamav';
import { handlePlatformJob } from './platform-jobs';
import { assertNoRoleStartupOption, withTenantTransactionPool } from './tenant-pool';
import { publishNotificationForEvent } from '../notifications/notification-outbox';
import { processNotificationEmail } from '../notifications/notification-email-worker';
import { processRecurringInvoice } from '../receivables/recurring-invoice-worker';
import { evaluateOperationalAlerts } from '../operations/alert-evaluator';
import * as Sentry from '@sentry/node';
import { withWorkerSpan, updateOperationalSnapshot } from '../observability-metrics';
import { workerConfigProblems, workerHeartbeatStatus } from './worker-config';

const problems = workerConfigProblems(process.env);
if (problems.length) throw new Error(`Platform worker disabled: ${problems.join('; ')}`);
const redisUrl = process.env.REDIS_URL!;
const redis=new URL(redisUrl);const connection={host:redis.hostname,port:Number(redis.port||6379),username:decodeURIComponent(redis.username),password:decodeURIComponent(redis.password),...(redis.protocol==='rediss:'?{tls:{}}:{}),maxRetriesPerRequest:null as null};
const discoveryUrl=process.env.WORKER_DATABASE_URL||process.env.DATABASE_URL;
if(!discoveryUrl)throw new Error('WORKER_DATABASE_URL or DATABASE_URL is required for queue discovery.');
assertNoRoleStartupOption(discoveryUrl,'WORKER_DATABASE_URL');
// This pool is server-side only and is used strictly for small durable queue metadata projections.
// It must never be exposed to request handlers or used to load business rows.
const pool=new Pool({connectionString:discoveryUrl,max:2});
const tenantDatabaseUrl=process.env.WORKER_TENANT_DATABASE_URL||discoveryUrl;
assertNoRoleStartupOption(tenantDatabaseUrl,'WORKER_TENANT_DATABASE_URL');
// Keep the connection URL free of startup role options. Every tenant query uses a
// short or explicit transaction with transaction-local role and tenant settings.
const tenantPool=new Pool({connectionString:tenantDatabaseUrl,max:5});
function tenantDb(tenantId:string){return withTenantTransactionPool(tenantPool,tenantId);}
const queue=new Queue('lexa-platform',{connection});
const workerId=`lexa-worker-${process.env.RENDER_INSTANCE_ID||randomUUID()}`;
const r2=()=>new S3Client({region:'auto',endpoint:`https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,credentials:{accessKeyId:process.env.R2_ACCESS_KEY_ID!,secretAccessKey:process.env.R2_SECRET_ACCESS_KEY!}});
async function scanAttachment(id:string,tenantId:string){
 // Resolve the attachment within its tenant transaction: queue IDs are never a trust boundary.
 const db=tenantDb(tenantId);
 const q=await db.query('SELECT * FROM platform_attachments WHERE id=$1 AND tenant_id=$2 AND status=$3',[id,tenantId,'pending_scan']);const f=q.rows[0];if(!f)return;
 const bucket=process.env.R2_BUCKET;if(!bucket)throw new Error('R2_BUCKET is required for attachment scanning.');
 const obj=await r2().send(new GetObjectCommand({Bucket:bucket,Key:f.object_key}));const bytes=Buffer.from(await obj.Body!.transformToByteArray());
 if(bytes.length!==Number(f.size_bytes)||createHash('sha256').update(bytes).digest('hex')!==f.sha256)throw new Error('File size or SHA-256 verification failed.');
 await scanWithClamAV(bytes);
 // A clean object is moved to an immutable clean namespace; its quarantine key is never reused.
 const cleanKey=`clean/${randomUUID()}`;
 await r2().send(new CopyObjectCommand({Bucket:bucket,Key:cleanKey,CopySource:`${bucket}/${encodeURIComponent(f.object_key).replace(/%2F/g,'/')}`,MetadataDirective:'COPY',CopySourceIfMatch:f.object_etag}));
 const updated=await db.query("UPDATE platform_attachments SET status='clean',object_key=$2,scan_engine='clamav',scan_metadata=scan_metadata||jsonb_build_object('clamav','clean'),scanned_at=now(),updated_at=now() WHERE id=$1 AND status='pending_scan' RETURNING id",[id,cleanKey]);
 if(!updated.rowCount){await r2().send(new DeleteObjectCommand({Bucket:bucket,Key:cleanKey}));return;}
 await r2().send(new DeleteObjectCommand({Bucket:bucket,Key:f.object_key}));
}
async function processOutbox(id:string,tenantId:string){
 const scopedPool=withTenantTransactionPool(tenantPool,tenantId);const c=await scopedPool.connect();let event:any;let attempt=0;
 try{await c.query('BEGIN');const q=await c.query("SELECT * FROM module_domain_events WHERE id=$1 AND tenant_id=$2 AND outbox_status IN ('pending','failed') AND dead_letter_at IS NULL AND next_attempt_at<=now() AND (lease_until IS NULL OR lease_until<now()) AND NOT EXISTS (SELECT 1 FROM platform_runtime_controls rc WHERE rc.tenant_id=module_domain_events.tenant_id AND rc.control_key='outbound_paused' AND rc.enabled) FOR UPDATE SKIP LOCKED",[id,tenantId]);event=q.rows[0];if(!event){await c.query('COMMIT');return;}attempt=Number(event.attempts)+1;await c.query("UPDATE module_domain_events SET lease_owner=$2,lease_until=now()+interval '2 minutes',attempts=$3 WHERE id=$1",[id,workerId,attempt]);await c.query('INSERT INTO platform_event_attempts(id,event_id,attempt_no,worker_id) VALUES($1,$2,$3,$4)',[randomUUID(),id,attempt,workerId]);await c.query('COMMIT');
  const handlers=new Set(['sale.completed','sale.payment.received','sale.return.recorded','sale.payment.direct_receipt_recorded','delivery.dispatch.created','delivery.lifecycle.changed','delivery.collection.reported','delivery.remittance.accepted','customer.credit.created','customer.credit.changed','customer.payment.overdue','customer.payment.reminder_due','customer_invoice.issued','customer_invoice.receipt_allocated','customer.created_from_lead','delivery.status_changed','delivery.remittance.allocated','delivery.picked_up','delivery.delivered','delivery.failed','import.preview.completed','import.approved','import.applied','import.failed','export.completed','export.failed','backup.completed','backup.failed','restore.completed','restore.failed','recurring_invoice.generated','recurring_invoice.failed','attachment.scan.clean','attachment.scan.quarantined','attachment.scan.failed','worker.queue.incident']);
  if(!handlers.has(String(event.event_type)))throw Object.assign(new Error(`No registered consumer for event type ${event.event_type}.`),{permanent:true});
  const payloadHash=createHash('sha256').update(JSON.stringify(event.payload||{})).digest('hex');
  await c.query("INSERT INTO platform_event_receipts(id,event_id,consumer,event_type,payload_hash) VALUES($1,$2,'platform-event-log',$3,$4) ON CONFLICT(event_id,consumer) DO NOTHING",[randomUUID(),id,event.event_type,payloadHash]);
  await publishNotificationForEvent(c,event);
  await c.query("UPDATE module_domain_events SET outbox_status='processed',processed_at=now(),last_error=NULL,lease_owner=NULL,lease_until=NULL WHERE id=$1 AND lease_owner=$2",[id,workerId]);
  await c.query("UPDATE platform_event_attempts SET outcome='completed',finished_at=now() WHERE event_id=$1 AND attempt_no=$2",[id,attempt]);
 }catch(error:any){await c.query('ROLLBACK').catch(()=>{});const permanent=Boolean(error?.permanent),dead=permanent||attempt>=8;const delay=Math.min(3600000,3000*2**Math.max(0,attempt-1)+Math.floor(Math.random()*2000));await c.query("UPDATE module_domain_events SET outbox_status='failed',dead_letter_at=CASE WHEN $2='dead_letter' THEN now() ELSE NULL END,last_error=$3,next_attempt_at=now()+($4::text||' milliseconds')::interval,lease_owner=NULL,lease_until=NULL WHERE id=$1",[id,dead?'dead_letter':'failed',String(error?.message||'outbox failure').slice(0,300),delay]);if(attempt)await c.query('UPDATE platform_event_attempts SET outcome=$3,error_code=$4,error_message=$5,finished_at=now() WHERE event_id=$1 AND attempt_no=$2',[id,attempt,dead?'dead_letter':'retry_wait',permanent?'PERMANENT':'RETRYABLE',String(error?.message||'').slice(0,300)]);if(!dead)throw error;}finally{c.release();}
}
async function processJob(id:string,tenantId:string){return handlePlatformJob(tenantPool,queue,r2(),workerId,id,tenantId);}
const worker=new Worker('lexa-platform',async job=>withWorkerSpan(job.name,typeof job.data?.correlationId==='string'?job.data.correlationId:undefined,async()=>{if(job.name==='scan-attachment')return scanAttachment(String(job.data.attachmentId),String(job.data.tenantId));if(job.name==='outbox-event')return processOutbox(String(job.data.eventId),String(job.data.tenantId));if(job.name==='platform-job')return processJob(String(job.data.jobId),String(job.data.tenantId));if(job.name==='notification-email'){const tenantId=String(job.data.tenantId);return processNotificationEmail(withTenantTransactionPool(tenantPool,tenantId),tenantId,String(job.data.deliveryId));}if(job.name==='recurring-invoice'){const tenantId=String(job.data.tenantId);return processRecurringInvoice(withTenantTransactionPool(tenantPool,tenantId),tenantId,String(job.data.scheduleId),String(job.data.scheduledDate));}throw new Error(`Unknown LEXA queue job: ${job.name}`);}), {connection,concurrency:4});
let workerFaulted = false;
worker.on('ready',()=>{workerFaulted=false;void pool.query("INSERT INTO platform_worker_heartbeats(worker_id,status,queues,last_seen_at,details) VALUES($1,'ready','[\"lexa-platform\"]',now(),$2::jsonb) ON CONFLICT(worker_id) DO UPDATE SET status='ready',last_seen_at=now(),details=EXCLUDED.details",[workerId,JSON.stringify({version:process.env.APP_VERSION||'dev',clamavHostConfigured:Boolean(process.env.CLAMAV_HOST),r2Configured:Boolean(process.env.R2_ACCESS_KEY_ID&&process.env.R2_SECRET_ACCESS_KEY)})]).catch(()=>{});});
worker.on('error',err=>{workerFaulted=true;Sentry.captureException(err,{tags:{component:'worker',worker_id:workerId}});void pool.query("UPDATE platform_worker_heartbeats SET status='degraded',details=jsonb_build_object('error',$2),last_seen_at=now() WHERE worker_id=$1",[workerId,String(err.message).slice(0,200)]).catch(()=>{});});
worker.on('failed',async(job,err)=>{Sentry.captureException(err,{tags:{component:'worker',job_type:job?.name||'unknown'}});if(!job)return;const id=String(job.data?.jobId||job.data?.attachmentId||job.data?.eventId||''),tenantId=String(job.data?.tenantId||'');if(job.name==='platform-job'&&id&&tenantId)await tenantDb(tenantId).query("UPDATE platform_jobs SET status=CASE WHEN attempts>=max_attempts THEN 'dead_letter' ELSE 'failed' END,error=$2,updated_at=now() WHERE id=$1 AND tenant_id=$3",[id,err.message,tenantId]).catch(()=>{});if(job.name==='scan-attachment'&&id&&tenantId&&(err instanceof InfectedFileError||job.attemptsMade>=Number(job.opts.attempts||1)))await tenantDb(tenantId).query("UPDATE platform_attachments SET status=$2,scan_engine=$3,scan_metadata=scan_metadata||jsonb_build_object('error',$4),updated_at=now() WHERE id=$1 AND tenant_id=$5 AND status='pending_scan'",[id,err instanceof InfectedFileError?'quarantined':'scan_failed',err instanceof InfectedFileError?'clamav-infected':'clamav-error',err.message.slice(0,300),tenantId]).catch(()=>{});});
let lastAlertEvaluation=0;
let lastNotificationRetentionSweep=0;
async function tick(){await pool.query("UPDATE notification_email_deliveries SET status='retry_wait',next_attempt_at=now(),last_error_code='DELIVERY_LEASE_EXPIRED',last_error_summary='A worker stopped while sending; retrying with the provider idempotency key.',updated_at=now() WHERE status='sending' AND attempted_at<now()-interval '5 minutes'").catch(e=>console.error('stale email delivery recovery failed',e));const redisDepth=await queue.getJobCounts();const clamavHealthy=await pingClamAV().then(()=>true).catch(()=>false);
 const heartbeatStatus=workerHeartbeatStatus({redisHealthy:!workerFaulted,clamavHealthy,r2Configured:Boolean(process.env.R2_ACCESS_KEY_ID&&process.env.R2_SECRET_ACCESS_KEY)});
 await pool.query("INSERT INTO platform_worker_heartbeats(worker_id,status,queues,last_seen_at,details) VALUES($1,$2,'[\"lexa-platform\"]',now(),$3::jsonb) ON CONFLICT(worker_id) DO UPDATE SET status=EXCLUDED.status,last_seen_at=now(),details=EXCLUDED.details",[workerId,heartbeatStatus,JSON.stringify({version:process.env.APP_VERSION||'dev',redis:'ok',redisDepth,clamav:clamavHealthy?'ok':'unavailable',r2Configured:Boolean(process.env.R2_ACCESS_KEY_ID&&process.env.R2_SECRET_ACCESS_KEY)})]);const backlog=await pool.query(`SELECT (SELECT count(*)::int FROM platform_attachments WHERE status='pending_scan') AS pending_scans,(SELECT count(*)::int FROM notification_email_deliveries WHERE status IN ('pending','retry_wait','sending')) AS pending_emails,(SELECT count(*)::int FROM recurring_invoice_occurrences WHERE status='failed') AS recurring_failures,(SELECT EXTRACT(EPOCH FROM (now()-min(created_at)))::int FROM platform_jobs WHERE status IN ('queued','retry_wait')) AS oldest_age,(SELECT EXTRACT(EPOCH FROM (now()-max(last_seen_at)))::int FROM platform_worker_heartbeats) AS heartbeat_age`);updateOperationalSnapshot({queueWaiting:Number(redisDepth.waiting||redisDepth.wait||0),queueActive:Number(redisDepth.active||0),queueDelayed:Number(redisDepth.delayed||0),queueFailed:Number(redisDepth.failed||0),pendingAttachmentScans:Number(backlog.rows[0]?.pending_scans||0),pendingEmailDeliveries:Number(backlog.rows[0]?.pending_emails||0),recurringInvoiceFailures:Number(backlog.rows[0]?.recurring_failures||0),oldestQueuedAgeSeconds:Number(backlog.rows[0]?.oldest_age||0),workerHeartbeatAgeSeconds:Number(backlog.rows[0]?.heartbeat_age||0),redisHealthy:true,clamavHealthy});const expired=await pool.query("SELECT id,tenant_id,object_key FROM platform_attachments WHERE status='pending_upload' AND upload_expires_at<now() ORDER BY created_at LIMIT 100");for(const f of expired.rows){await r2().send(new DeleteObjectCommand({Bucket:process.env.R2_BUCKET,Key:f.object_key})).catch(()=>{});await tenantDb(String(f.tenant_id)).query("UPDATE platform_attachments SET status='deleted',retention_state='deleted',deleted_at=now(),updated_at=now() WHERE id=$1 AND status='pending_upload'",[f.id]);}const attachments=await pool.query("SELECT id,tenant_id FROM platform_attachments WHERE status='pending_scan' ORDER BY created_at LIMIT 25");for(const a of (clamavHealthy?attachments.rows:[]))await queue.add('scan-attachment',{attachmentId:a.id,tenantId:a.tenant_id},{jobId:`scan-${a.id}`,attempts:5,backoff:{type:'exponential',delay:5000},removeOnComplete:1000});const events=await pool.query("SELECT id,tenant_id,attempts,correlation_id FROM module_domain_events WHERE outbox_status IN ('pending','failed') AND dead_letter_at IS NULL AND attempts<8 AND next_attempt_at<=now() AND NOT EXISTS (SELECT 1 FROM platform_runtime_controls rc WHERE rc.tenant_id=module_domain_events.tenant_id AND rc.control_key='outbound_paused' AND rc.enabled) ORDER BY created_at LIMIT 100");for(const e of events.rows)await queue.add('outbox-event',{eventId:e.id,tenantId:e.tenant_id,correlationId:e.correlation_id||undefined},{jobId:`outbox-${e.id}-${e.attempts}`,attempts:5,backoff:{type:'exponential',delay:3000},removeOnComplete:1000});const jobs=await pool.query("SELECT id,tenant_id,correlation_id FROM platform_jobs WHERE status IN ('queued','failed') AND attempts<max_attempts AND available_at<=now() AND NOT EXISTS (SELECT 1 FROM platform_runtime_controls rc WHERE rc.tenant_id=platform_jobs.tenant_id AND rc.control_key='outbound_paused' AND rc.enabled) ORDER BY created_at LIMIT 25");for(const j of jobs.rows)await queue.add('platform-job',{jobId:j.id,tenantId:j.tenant_id,correlationId:j.correlation_id||undefined},{jobId:`platform-${j.id}`,attempts:5,backoff:{type:'exponential',delay:5000},removeOnComplete:1000});const emails=await pool.query("SELECT d.id,d.tenant_id,d.attempts,e.correlation_id FROM notification_email_deliveries d LEFT JOIN module_domain_events e ON e.id=d.source_event_id WHERE status IN ('pending','retry_wait') AND next_attempt_at<=now() AND NOT EXISTS (SELECT 1 FROM platform_runtime_controls rc WHERE rc.tenant_id=d.tenant_id AND rc.control_key='outbound_paused' AND rc.enabled) ORDER BY next_attempt_at LIMIT 50");for(const e of emails.rows)await queue.add('notification-email',{deliveryId:e.id,tenantId:e.tenant_id,correlationId:e.correlation_id||undefined},{jobId:`notification-email-${e.id}-${e.attempts}`,attempts:1,removeOnComplete:1000});const schedules=await pool.query("SELECT s.id,s.tenant_id,s.next_run_date,s.correlation_id FROM recurring_invoice_schedules s WHERE s.status='active' AND s.next_run_at<=now() AND NOT EXISTS (SELECT 1 FROM platform_runtime_controls rc WHERE rc.tenant_id=s.tenant_id AND rc.control_key='recurring_jobs_paused' AND rc.enabled) ORDER BY s.next_run_at LIMIT 25");for(const s of schedules.rows)await queue.add('recurring-invoice',{scheduleId:s.id,tenantId:s.tenant_id,scheduledDate:new Date(s.next_run_date).toISOString().slice(0,10),correlationId:s.correlation_id||undefined},{jobId:`recurring-${s.id}-${new Date(s.next_run_date).toISOString().slice(0,10)}`,attempts:1,removeOnComplete:1000,removeOnFail:1000});if(Date.now()-lastAlertEvaluation>60000){lastAlertEvaluation=Date.now();await evaluateOperationalAlerts(pool).catch(e=>console.error('alert evaluation failed',e));}if(Date.now()-lastNotificationRetentionSweep>3600000){lastNotificationRetentionSweep=Date.now();await pool.query("WITH expired AS (SELECT id FROM business_notifications WHERE expires_at IS NOT NULL AND expires_at<now() AND NOT EXISTS (SELECT 1 FROM notification_email_deliveries d WHERE d.notification_id=business_notifications.id) ORDER BY expires_at LIMIT 500) DELETE FROM business_notifications n USING expired e WHERE n.id=e.id").catch(e=>console.error('notification retention sweep failed',e));await pool.query("DELETE FROM notification_email_deliveries WHERE created_at<now()-interval '365 days' AND status IN ('sent','delivered','failed','suppressed','bounced','complained')").catch(e=>console.error('email retention sweep failed',e));}}
let shuttingDown = false;
let inFlightTick: Promise<void> | null = null;
function scheduleTick(): void {
 if (shuttingDown || inFlightTick) return;
 const current = tick();
 inFlightTick = current;
 void current.catch((error) => console.error('worker tick failed', error))
   .finally(() => { if (inFlightTick === current) inFlightTick = null; });
}
scheduleTick();
const tickTimer = setInterval(scheduleTick, 10_000);
const shutdown=async()=>{
 if (shuttingDown) return;
 shuttingDown=true;
 clearInterval(tickTimer);
 try {
  // Wait for discovery to finish enqueueing before shutting down the queue.
  if (inFlightTick) await inFlightTick.catch(()=>{});
  await worker.close();
  await queue.close();
  await tenantPool.end();
  await pool.end();
 } catch (error) {
  console.error('LEXA worker shutdown failed',error);
  process.exitCode=1;
 }
};
process.on('SIGTERM',()=>void shutdown());process.on('SIGINT',()=>void shutdown());
console.log(`LEXA platform worker ${workerId} started`);
