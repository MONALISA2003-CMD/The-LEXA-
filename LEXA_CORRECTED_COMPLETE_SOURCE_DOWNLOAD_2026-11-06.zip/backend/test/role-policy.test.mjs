import test from 'node:test';
import assert from 'node:assert/strict';
import { hasPermission, permissionForRequest, normalizeRole, isWorkspaceAdministrator, canAccessBranch } from '../src/authorization/role-policy.ts';

test('normalizes role labels consistently', () => {
  assert.equal(normalizeRole('Business Manager'), 'business_manager');
  assert.equal(normalizeRole('Owner / Administrator'), 'owner_administrator');
});

test('owner and business manager can operate business domains', () => {
  assert.equal(hasPermission('owner', 'finance.write'), true);
  assert.equal(hasPermission('Business Manager', 'inventory.write'), true);
  assert.equal(hasPermission('admin', 'workspace.manage'), false);
  assert.equal(hasPermission('owner', 'workspace.manage'), true);
});

test('accountant is scoped to finance and procurement rather than stock operations', () => {
  assert.equal(hasPermission('accountant', 'finance.write'), true);
  assert.equal(hasPermission('accountant', 'procurement.write'), true);
  assert.equal(hasPermission('accountant', 'inventory.write'), false);
  assert.equal(hasPermission('accountant', 'workspace.manage'), false);
});

test('cashier can make sales but cannot post finance or adjust stock', () => {
  assert.equal(hasPermission('cashier', 'sales.write'), true);
  assert.equal(hasPermission('cashier', 'sales.return'), false);
  assert.equal(hasPermission('cashier', 'finance.write'), false);
  assert.equal(hasPermission('cashier', 'inventory.write'), false);
  assert.equal(hasPermission('cashier', 'cash.manage'), true);
  assert.equal(hasPermission('cashier', 'finance.write'), false);
  assert.equal(permissionForRequest('POST', '/api/v1/workspaces/w/branches/b/finance/cash-sessions'), 'cash.manage');
});

test('unknown roles fail closed for writes', () => {
  assert.equal(hasPermission('super-user-typo', 'finance.write'), false);
  assert.equal(hasPermission('member', 'inventory.write'), false);
});

test('maps transactional endpoints to their protected capability', () => {
  assert.equal(permissionForRequest('POST', '/api/v1/workspaces/w/branches/b/sales/complete'), 'sales.write');
  assert.equal(permissionForRequest('POST', '/api/v1/workspaces/w/branches/b/sales/s/returns'), 'sales.return');
  assert.equal(permissionForRequest('POST', '/api/v1/workspaces/w/branches/b/inventory/movements'), 'inventory.write');
  assert.equal(permissionForRequest('POST', '/api/v1/workspaces/w/branches/b/payables/payments'), 'finance.write');
  assert.equal(permissionForRequest('GET', '/api/v1/workspaces/w/branches/b/payables/invoices'), 'finance.read');
});

test('maps operational register writes by module family', () => {
  assert.equal(permissionForRequest('PUT', '/api/v1/workspaces/w/branches/b/modules/payroll/records/r', { moduleId: 'payroll' }), 'payroll.write');
  assert.equal(permissionForRequest('PUT', '/api/v1/workspaces/w/branches/b/modules/stock-counts/records/r', { moduleId: 'stock-counts' }), 'inventory.write');
  assert.equal(permissionForRequest('PUT', '/api/v1/workspaces/w/branches/b/modules/accounting/records/r', { moduleId: 'accounting' }), 'finance.write');
});

test('branch-scope management is an owner/admin capability', () => {
  assert.equal(permissionForRequest('GET', '/api/v1/workspaces/w/memberships/u/branches'), 'workspace.manage');
  assert.equal(permissionForRequest('GET', '/api/v1/workspaces/w/members'), 'workspace.manage');
  assert.equal(permissionForRequest('PUT', '/api/v1/workspaces/w/memberships/u/role'), 'workspace.manage');
  assert.equal(hasPermission('owner', 'workspace.manage'), true);
  assert.equal(hasPermission('accountant', 'workspace.manage'), false);
});

test('finance and sales permissions are separated', () => {
  assert.equal(permissionForRequest('GET', '/api/v1/workspaces/w/branches/b/receivables/invoices'), 'finance.read');
  assert.equal(permissionForRequest('POST', '/api/v1/workspaces/w/branches/b/receivables/receipts'), 'finance.write');
  assert.equal(permissionForRequest('POST', '/api/v1/workspaces/w/branches/b/commerce/sales-orders/o/fulfil'), 'fulfilment.write');
  assert.equal(hasPermission('cashier', 'finance.write'), false);
});


test('branch administrators bypass branch grants and empty grant sets preserve legacy scope', () => {
  assert.equal(isWorkspaceAdministrator('Owner / Administrator'), true);
  assert.equal(canAccessBranch('owner', 'restricted', false), true);
  assert.equal(canAccessBranch('member', 'all', false), true);
  assert.equal(canAccessBranch('member', 'restricted', true), true);
  assert.equal(canAccessBranch('member', 'restricted', false), false);
});

test('workspace administrators normalize aliases consistently', () => {
  assert.equal(isWorkspaceAdministrator('administrator'), false);
  assert.equal(isWorkspaceAdministrator('admin'), false);
  assert.equal(isWorkspaceAdministrator('business manager'), false);
});

test('restricted branch scope can deliberately deny every branch while all mode stays backward-compatible', () => {
  assert.equal(canAccessBranch('member', 'all', false), true);
  assert.equal(canAccessBranch('member', 'restricted', false), false);
  assert.equal(canAccessBranch('member', 'restricted', true), true);
  assert.equal(canAccessBranch('owner', 'restricted', false), true);
});


test('maps Workstream 5 procurement, warehouse and manufacturing transactions to scoped capabilities', () => {
  const base = '/api/v1/workspaces/w/branches/b/supply-chain';
  assert.equal(permissionForRequest('POST', `${base}/procurement/purchase-orders/po/receipts`), 'procurement.receive');
  assert.equal(permissionForRequest('POST', `${base}/procurement/awards/award/approve`), 'procurement.approve');
  assert.equal(permissionForRequest('POST', `${base}/procurement/approval-rules`), 'workspace.manage');
  assert.equal(permissionForRequest('POST', `${base}/inventory/stock-counts/count/review`), 'inventory.write');
  assert.equal(permissionForRequest('POST', `${base}/inventory/stock-counts/count/approve`), 'inventory.approve');
  assert.equal(permissionForRequest('GET', `${base}/inventory/transfers`), 'inventory.read');
  assert.equal(permissionForRequest('POST', `${base}/inventory/transfers`), 'inventory.write');
  assert.equal(permissionForRequest('POST', `${base}/manufacturing/work-orders/wo/release`), 'manufacturing.write');
  assert.equal(permissionForRequest('POST', `${base}/quality/inspections/inspection/decision`), 'quality.approve');
});

test('AI execution belongs to owner roles only, including direct API requests', () => {
  for(const role of ['owner','owner_administrator']) {
    assert.equal(hasPermission(role,'intelligence.run'), true);
  }
  for(const role of ['accountant','administrator','manager','cashier','sales']) {
    assert.equal(hasPermission(role,'intelligence.run'), false);
  }
  assert.equal(permissionForRequest('GET','/api/v1/workspaces/w/branches/b/intelligence/status'),'intelligence.run');
  assert.equal(permissionForRequest('GET','/api/v1/workspaces/w/branches/b/intelligence/brief'),'intelligence.run');
});
