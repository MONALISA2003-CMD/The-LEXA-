import { readFileSync } from 'node:fs';
import { resolve as resolvePath } from 'node:path';
import { describe, expect, it } from 'vitest';
// Resolve from Vite/Vitest's project working directory. import.meta.url may be
// rewritten to a non-file URL by the test transform, which fs cannot read.
const css = readFileSync(resolvePath(process.cwd(), 'src/styles/lexa-brand.css'), 'utf8');
type Theme = 'light' | 'dark';
function themeBlock(theme: Theme): string { const pattern = theme === 'light' ? /:root\{color-scheme:light;[\s\S]*?\}/ : /:root\[data-theme=['"]?dark['"]?\]\{color-scheme:dark;[\s\S]*?\}/; const m = css.match(pattern); if (!m) throw new Error('Missing token block ' + theme); return m[0]; }
function declarations(theme: Theme): Map<string,string> { const a = [...themeBlock('light').matchAll(/(--[a-z0-9-]+):([^;]+);/g)].map(m=>[m[1]!,m[2]!] as const); const b = theme === 'dark' ? [...themeBlock('dark').matchAll(/(--[a-z0-9-]+):([^;]+);/g)].map(m=>[m[1]!,m[2]!] as const) : []; return new Map([...a,...b]); }
function resolve(name:string,theme:Theme,seen=new Set<string>()):string { if(seen.has(name)) throw new Error('Circular token '+name); seen.add(name); const v=declarations(theme).get(name); if(!v) throw new Error('Missing token '+name); const r=v.match(/var\((--[a-z0-9-]+)\)/); if(r) return resolve(r[1]!,theme,seen); if(!/^#[0-9a-f]{6}$/i.test(v.trim())) throw new Error('Expected hex token '+name+': '+v); return v.trim(); }
function lum(h:string):number { const c=h.slice(1).match(/.{2}/g)!.map(v=>parseInt(v,16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4); return .2126*c[0]!+.7152*c[1]!+.0722*c[2]!; }
function ratio(theme:Theme,fg:string,bg:string):number { const p=[lum(resolve(fg,theme)),lum(resolve(bg,theme))].sort((a,b)=>b-a); return (p[0]!+.05)/(p[1]!+.05); }
describe('LEXA semantic colour tokens',()=>{
  it.each(['light','dark'] as const)('%s text, action, status and disabled pairs meet WCAG AA',theme=>{const pairs=[['--color-text-primary','--color-bg-canvas'],['--color-text-secondary','--color-surface'],['--color-text-muted','--color-bg-canvas'],['--color-primary','--color-on-primary'],['--color-success','--color-success-soft'],['--color-warning','--color-warning-soft'],['--color-danger','--color-danger-soft'],['--color-info','--color-info-soft'],['--color-disabled-text','--color-disabled-bg']] as const; for(const [fg,bg] of pairs) expect(ratio(theme,fg,bg),fg+' / '+bg).toBeGreaterThanOrEqual(4.5);});
  it.each(['light','dark'] as const)('%s focus and control borders meet 3:1',theme=>{expect(ratio(theme,'--color-focus','--color-surface')).toBeGreaterThanOrEqual(3);expect(ratio(theme,'--color-border-control','--color-surface')).toBeGreaterThanOrEqual(3);});
  it('defines the semantic roles in both theme token blocks',()=>{for(const role of ['--color-primary','--color-primary-hover','--color-secondary','--color-text-primary','--color-text-secondary','--color-bg-canvas','--color-surface','--color-border','--color-focus','--color-success','--color-warning','--color-danger','--color-disabled-text','--color-disabled-bg']){expect(themeBlock('light')).toContain(role+':');expect(themeBlock('dark')).toContain(role+':');}});
});
