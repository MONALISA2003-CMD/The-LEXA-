import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const controller=readFileSync(new URL('../src/platform/platform.controller.ts',import.meta.url),'utf8');
const migration=readFileSync(new URL('../prisma/migrations/20261031200000_workstream7_platform_operations/migration.sql',import.meta.url),'utf8');
const worker=readFileSync(new URL('../src/platform/worker.ts',import.meta.url),'utf8');
const clamav=readFileSync(new URL('../src/platform/clamav.ts',import.meta.url),'utf8');
test('R2 uses private S3-compatible endpoint and automatic region',()=>{assert.match(controller,/region:'auto'/);assert.match(controller,/r2\.cloudflarestorage\.com/);assert.doesNotMatch(controller,/publicAccess|r2\.dev/);});
test('upload is short lived, capped, MIME allowlisted and checksum bound',()=>{assert.match(controller,/expiresIn:600/);assert.match(controller,/25\*1024\*1024/);assert.match(controller,/allowed\.has\(type\)/);assert.match(controller,/x-amz-meta-lexa-sha256/);assert.match(controller,/IfNoneMatch:'\*'/);});
test('download is clean-only and limited to uploader or workspace admin',()=>{assert.match(controller,/f\.status!=='clean'/);assert.match(controller,/uploaded_by_user_id!==actor\.userId/);});
test('tenant and branch references are database constrained',()=>{assert.match(migration,/FOREIGN KEY\(tenant_id,branch_id\) REFERENCES branches\(tenant_id,id\)/);});
test('scanner fails closed and verifies SHA-256 before marking clean',()=>{assert.match(worker,/scanWithClamAV\(bytes\)/);assert.match(clamav,/host/);assert.match(clamav,/timeout/);assert.match(worker,/status='clean'/);assert.match(worker,/'scan_failed'/);assert.match(worker,/'quarantined'/);assert.match(worker,/InfectedFileError/);assert.match(worker,/createHash\('sha256'\)/);});
test('outbox unknown events are not acknowledged as processed',()=>{assert.match(worker,/No registered consumer for event type/);});

test('attachment completion is bound to the authenticated uploader',()=>{assert.match(controller,/const actor=await this\.actor\(req,w,b\)[\s\S]*?uploaded_by_user_id!==actor\.userId/);assert.doesNotMatch(controller,/uploaded_by_user_id!==a\.userId/);});
test('attachment listing and download require scoped access',()=>{assert.match(controller,/@Get\('attachments'\)/);assert.match(controller,/td\.participants\.includes\(actor\.userId\)/);assert.match(controller,/status!=='clean'/);});
test('R2 upload returns required signed headers and download is short-lived',()=>{assert.match(controller,/requiredHeaders:\{'Content-Type':type,'x-amz-meta-lexa-sha256':hash,'If-None-Match':'\*'\}/);assert.match(controller,/expiresIn:60/);});

const operationsController=readFileSync(new URL('../src/operations/operations.controller.ts',import.meta.url),'utf8');
test('stored alert runbook paths resolve to the renamed operations runbooks without database mutation',()=>{assert.match(operationsController,/LEGACY_RUNBOOK_PATHS/);assert.match(operationsController,/docs\/operations\/runbooks\/attachment-scanning\.md/);assert.match(operationsController,/LEGACY_RUNBOOK_PATHS\[rule\.runbook_path\]/);assert.match(operationsController,/runbook\.startsWith\('docs\/operations\/runbooks\/'\)/);});
