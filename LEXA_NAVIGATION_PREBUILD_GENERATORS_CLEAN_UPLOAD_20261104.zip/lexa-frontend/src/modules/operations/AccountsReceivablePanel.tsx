import { useState, type FormEvent } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { AlertCircle, ArrowDownLeft, CheckCircle2, FilePlus2, FileText, RefreshCw, Wallet, Printer } from 'lucide-react';
import { toast } from 'sonner';
import { useWorkspace } from '../../app/WorkspaceContext';
import { apiReceivables, type EligibleSale, type ReceivablesInvoice } from '../../data/remote/apiReceivables';
import { isApiProvider } from '../../data/remote/runtimeConfig';
import './accounts-receivable.css';
import SellingNav,{SellingPerformance} from '../selling/SellingNav';
import InvoiceDocument from './InvoiceDocument';

function localDate() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Kampala', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now);
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}
function currencyScale(currency: string) {
  try { return 10 ** (new Intl.NumberFormat('en', { style: 'currency', currency }).resolvedOptions().maximumFractionDigits ?? 0); }
  catch { return 1; }
}
function money(minor: number, currency: string) {
  const scale = currencyScale(currency);
  return new Intl.NumberFormat('en-UG', { style: 'currency', currency, maximumFractionDigits: currency === 'UGX' ? 0 : 2 }).format(minor / scale);
}
function labelStatus(status: string) {
  return status.replace(/_/g, ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
}
function asMajor(minor: number, currency: string) {
  return String(minor / currencyScale(currency));
}

export default function AccountsReceivablePanel() {
  const { workspace, branch } = useWorkspace();
  const client = useQueryClient();
  const scope = { workspaceId: workspace.id, branchId: branch.id };
  const today = localDate();
  const [issueDates, setIssueDates] = useState<Record<string, string>>({});
  const [dueDates, setDueDates] = useState<Record<string, string>>({});
  const [busyId, setBusyId] = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState<ReceivablesInvoice | null>(null);
  const [printInvoice, setPrintInvoice] = useState<ReceivablesInvoice | null>(null);
  const [paymentDate, setPaymentDate] = useState(today);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [paymentReference, setPaymentReference] = useState('');
  const [receiptIdempotencyKey, setReceiptIdempotencyKey] = useState('');

  const invoicesQuery = useQuery({
    queryKey: ['ar-invoices', workspace.id, branch.id],
    queryFn: () => apiReceivables.listInvoices(scope),
    enabled: isApiProvider,
  });
  const eligibleQuery = useQuery({
    queryKey: ['ar-eligible-sales', workspace.id, branch.id],
    queryFn: () => apiReceivables.listEligibleSales(scope),
    enabled: isApiProvider,
  });
  const receiptsQuery = useQuery({
    queryKey: ['ar-receipts', workspace.id, branch.id],
    queryFn: () => apiReceivables.listReceipts(scope),
    enabled: isApiProvider,
  });
  const summaryQuery = useQuery({
    queryKey: ['ar-summary', workspace.id, branch.id],
    queryFn: () => apiReceivables.summary(scope),
    enabled: isApiProvider,
  });

  const invoices = invoicesQuery.data ?? [];
  const eligibleSales = eligibleQuery.data ?? [];
  const receipts = receiptsQuery.data ?? [];
  const allFailed = [summaryQuery, eligibleQuery, invoicesQuery, receiptsQuery].filter(x=>x.isError).length >= 3;
  const summary = summaryQuery.data;

  async function refresh() {
    await Promise.all([
      client.invalidateQueries({ queryKey: ['ar-invoices', workspace.id, branch.id] }),
      client.invalidateQueries({ queryKey: ['ar-eligible-sales', workspace.id, branch.id] }),
      client.invalidateQueries({ queryKey: ['ar-receipts', workspace.id, branch.id] }),
      client.invalidateQueries({ queryKey: ['ar-summary', workspace.id, branch.id] }),
      client.invalidateQueries({ queryKey: ['sales', workspace.id] }),
      client.invalidateQueries({ queryKey: ['dashboard', workspace.id, branch.id] }),
      client.invalidateQueries({ queryKey: ['module-register', workspace.id, branch.id, 'sales-invoices'] }),
    ]);
  }

  async function createInvoice(event: FormEvent<HTMLFormElement>, sale: EligibleSale) {
    event.preventDefault();
    const issueDate = issueDates[sale.id] || today;
    const dueDate = dueDates[sale.id] || '';
    if (!dueDate) { toast.error('Choose a due date before creating the invoice.'); return; }
    if (dueDate < issueDate) { toast.error('The due date cannot be earlier than the invoice date.'); return; }
    setBusyId(sale.id);
    try {
      const invoice = await apiReceivables.createInvoice(scope, { saleId: sale.id, issueDate, dueDate });
      toast.success('Invoice draft created', { description: `${invoice.invoiceNumber} · ${money(invoice.totalMinor, workspace.currency)}` });
      await refresh();
    } catch (error) {
      toast.error('Invoice was not created', { description: error instanceof Error ? error.message : 'Check the sale and try again.' });
    } finally { setBusyId(''); }
  }

  async function issueInvoice(invoice: ReceivablesInvoice) {
    setBusyId(invoice.id);
    try {
      const issued = await apiReceivables.issueInvoice(scope, invoice.id);
      toast.success('Customer invoice issued', { description: `${issued.invoiceNumber} · ${money(issued.balanceDueMinor, workspace.currency)} outstanding` });
      await refresh();
    } catch (error) {
      toast.error('Invoice was not issued', { description: error instanceof Error ? error.message : 'Check the invoice and try again.' });
    } finally { setBusyId(''); }
  }

  async function voidInvoice(invoice: ReceivablesInvoice) {
    if (!window.confirm(`Void draft invoice ${invoice.invoiceNumber}? The completed sale will remain unchanged.`)) return;
    setBusyId(invoice.id);
    try {
      await apiReceivables.voidDraftInvoice(scope, invoice.id);
      toast.success('Draft invoice voided', { description: `${invoice.invoiceNumber} · no sales or stock entries were changed` });
      await refresh();
    } catch (error) {
      toast.error('Draft invoice was not voided', { description: error instanceof Error ? error.message : 'Refresh the register and try again.' });
    } finally { setBusyId(''); }
  }

  function openReceipt(invoice: ReceivablesInvoice) {
    setSelectedInvoice(invoice);
    setPaymentAmount(asMajor(invoice.balanceDueMinor, workspace.currency));
    setPaymentDate(today);
    setPaymentReference('');
    setReceiptIdempotencyKey(crypto.randomUUID());
  }

  async function recordReceipt(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedInvoice) return;
    const amountMinor = Math.round(Number(paymentAmount) * currencyScale(workspace.currency));
    if (!Number.isSafeInteger(amountMinor) || amountMinor <= 0 || amountMinor > selectedInvoice.balanceDueMinor) {
      toast.error('Enter a positive receipt amount no greater than the invoice balance.');
      return;
    }
    setBusyId(selectedInvoice.id);
    try {
      const receipt = await apiReceivables.recordReceipt(scope, {
        paymentDate,
        method: paymentMethod,
        ...(paymentReference.trim() ? { reference: paymentReference.trim() } : {}),
        amountMinor,
        idempotencyKey: receiptIdempotencyKey,
        allocations: [{ invoiceId: selectedInvoice.id, amountMinor }],
      });
      toast.success('Customer receipt recorded', { description: `${receipt.receiptNumber} · ${money(receipt.amountMinor, workspace.currency)} allocated to ${selectedInvoice.invoiceNumber}` });
      setSelectedInvoice(null);
      setReceiptIdempotencyKey('');
      await refresh();
    } catch (error) {
      toast.error('Receipt was not recorded', { description: error instanceof Error ? error.message : 'Check the receipt and allocation.' });
    } finally { setBusyId(''); }
  }

  if (!isApiProvider) {
    return <section className="ar-panel"><SellingNav compact/><SellingPerformance/><div className="ar-unavailable"><AlertCircle size={19} /><div><strong>Customer accounts require a connected LEXA business.</strong><p>Sign in to your connected business to issue invoices and record customer payments. Drafts saved on this device are not posted accounting transactions.</p></div></div></section>;
  }

  return (
    <section className="ar-panel"><SellingNav compact/><SellingPerformance/>
      <header className="ar-heading">
        <div className="ar-heading-icon"><Wallet size={20} /></div>
        <div className="ar-heading-copy"><span className="eyebrow eyebrow-blue">CUSTOMER BILLING</span><h3>Invoices & customer payments</h3><p>Issue invoices from completed sales, record receipts, allocate cash and monitor overdue customer balances.</p></div>
        <button type="button" className="button button-secondary button-small" onClick={() => void refresh()} disabled={Boolean(busyId)}><RefreshCw size={14} /> Refresh</button>
      </header>

      {allFailed&&<div className="ar-connection-banner" role="alert"><AlertCircle size={22}/><div><strong>We couldn't open your customer billing records</strong><p>Your business information is still on your account. Check your connection and try again. If it continues, ask the LEXA support team to check your business access.</p></div><button type="button" className="button button-primary" onClick={()=>void refresh()}><RefreshCw size={15}/> Try again</button></div>}
      {!allFailed&&<div className="ar-activity-card"><h4>Unpaid invoices by age</h4>
        <p>The amounts your customers currently owe.</p>
        {summaryQuery.isLoading&&<span>Loading outstanding balances…</span>}
        {summary&&<div className="ar-ageing-bars">{([
          ['Not yet due',summary.currentMinor],['1–30 days late',summary.days1to30Minor],
          ['31–60 days late',summary.days31to60Minor],['61–90 days late',summary.days61to90Minor],
          ['Over 90 days late',summary.over90Minor]] as Array<[string,number]>).map(([label,value])=>{
            const peak=Math.max(summary.currentMinor,summary.days1to30Minor,summary.days31to60Minor,summary.days61to90Minor,summary.over90Minor,1);
            return <div key={label} className="ar-ageing-line"><span>{label}</span><div><i style={{width:String(value/peak*100)+'%'}}/></div><strong>{money(value,workspace.currency)}</strong></div>
          })}</div>}
      </div>}
      {!allFailed&&<div className="ar-integrity-note"><CheckCircle2 size={16} /><span>Your invoices stay connected to completed sales. Customer payments update their balances and sales history. LEXA records money you confirm receiving; it does not transfer it.</span></div>}

      {summaryQuery.isError ? <div className="inline-error">Could not load the receivables summary. {summaryQuery.error instanceof Error ? summaryQuery.error.message : ''}</div> : <div className="ar-summary-grid">
        <article><span>Outstanding</span><strong>{money(summary?.outstandingMinor ?? 0, workspace.currency)}</strong><small>{summary?.openCount ?? 0} open invoices</small></article>
        <article><span>Overdue</span><strong>{money(summary?.overdueMinor ?? 0, workspace.currency)}</strong><small>{summary?.overdueCount ?? 0} overdue invoices</small></article>
        <article><span>Not yet due</span><strong>{money(summary?.currentMinor ?? 0, workspace.currency)}</strong><small>Current receivables</small></article>
        <article><span>Total invoices</span><strong>{(summary?.invoiceCount ?? 0).toLocaleString()}</strong><small>Issued invoices</small></article>
      </div>}
      {summary && <div className="ar-ageing-grid" aria-label="Overdue ageing"><div><span>1–30 days</span><strong>{money(summary.days1to30Minor, workspace.currency)}</strong></div><div><span>31–60 days</span><strong>{money(summary.days31to60Minor, workspace.currency)}</strong></div><div><span>61–90 days</span><strong>{money(summary.days61to90Minor, workspace.currency)}</strong></div><div><span>Over 90 days</span><strong>{money(summary.over90Minor, workspace.currency)}</strong></div></div>}

      <section className="ar-section">
        <div className="ar-section-heading"><div><span className="eyebrow eyebrow-blue">STEP 1</span><h4>Completed sales ready to invoice</h4><p>Only completed sales with a named customer and no recorded return are eligible.</p></div><span className="ar-count">{eligibleQuery.isError?'Unavailable':eligibleSales.length+' eligible'}</span></div>
        {eligibleQuery.isError ? <div className="inline-error">Could not load completed sales. {eligibleQuery.error instanceof Error ? eligibleQuery.error.message : ''}</div> : eligibleQuery.isLoading ? <div className="ar-empty">Loading completed sales…</div> : eligibleSales.length === 0 ? <div className="ar-empty">No eligible completed sales. Complete a named-customer sale or fulfil a sales order first.</div> : <div className="ar-sale-list">
          {eligibleSales.map((sale) => <form className="ar-sale-row" key={sale.id} onSubmit={(event) => void createInvoice(event, sale)}>
            <div className="ar-sale-main"><strong>{sale.receiptNumber}</strong><span>{sale.customerName}</span><small>{sale.lineCount} lines · {new Date(sale.createdAt).toLocaleDateString()}</small></div>
            <div className="ar-sale-total"><span>Sale total</span><strong>{money(sale.totalMinor, workspace.currency)}</strong></div>
            <label className="field-label">Invoice date<input type="date" value={issueDates[sale.id] ?? today} onChange={(event) => setIssueDates((current) => ({ ...current, [sale.id]: event.target.value }))} required /></label>
            <label className="field-label">Due date<input type="date" min={issueDates[sale.id] ?? today} value={dueDates[sale.id] ?? ''} onChange={(event) => setDueDates((current) => ({ ...current, [sale.id]: event.target.value }))} required /></label>
            <button type="submit" className="button button-primary button-small" disabled={Boolean(busyId)}><FilePlus2 size={14} /> {busyId === sale.id ? 'Creating…' : 'Create draft'}</button>
          </form>)}
        </div>}
      </section>

      <section className="ar-section">
        <div className="ar-section-heading"><div><span className="eyebrow eyebrow-blue">STEP 2</span><h4>Customer invoice register</h4><p>Review a draft and issue it. Void and recreate a draft if its dates are wrong. Issued invoices are not editable; use the credit-note workflow for post-issue corrections.</p></div><span className="ar-count">{invoicesQuery.isError?'Unavailable':invoices.length+' invoices'}</span></div>
        {invoicesQuery.isError ? <div className="inline-error">Could not load customer invoices. {invoicesQuery.error instanceof Error ? invoicesQuery.error.message : ''}</div> : invoicesQuery.isLoading ? <div className="ar-empty">Loading invoices…</div> : invoices.length === 0 ? <div className="ar-empty">No customer invoices yet. Create a draft from a completed sale above.</div> : <div className="ar-invoice-list">
          {invoices.map((invoice) => <article className="ar-invoice-card" key={invoice.id}>
            <div className="ar-invoice-top"><div><strong>{invoice.invoiceNumber}</strong><span>{invoice.customerName}</span><small>Sale {invoice.sourceSaleId.slice(0, 8)} · Due {invoice.dueDate}</small></div><span className={'ar-status ar-status-' + invoice.status}>{labelStatus(invoice.status)}</span></div>
            <div className="ar-invoice-amounts"><div><span>Total</span><strong>{money(invoice.totalMinor, workspace.currency)}</strong></div><div><span>Received</span><strong>{money(invoice.receivedMinor, workspace.currency)}</strong></div><div><span>Balance due</span><strong>{money(invoice.balanceDueMinor, workspace.currency)}</strong></div></div>
            {invoice.lines.length > 0 && <details className="ar-lines-details"><summary>{invoice.lines.length} invoice lines</summary><div>{invoice.lines.map((line) => <div key={line.id}><span>{line.productName} × {line.quantity}</span><strong>{money(line.lineTotalMinor, workspace.currency)}</strong></div>)}</div></details>}
            <div className="ar-invoice-actions">
              <button className="button button-secondary button-small" type="button" onClick={()=>setPrintInvoice(invoice)}><Printer size={14}/> Preview / print</button>
              {invoice.status === 'draft' && <><button className="button button-primary button-small" type="button" onClick={() => void issueInvoice(invoice)} disabled={Boolean(busyId)}><FileText size={14} /> {busyId === invoice.id ? 'Processing…' : 'Issue invoice'}</button><button className="button button-secondary button-small" type="button" onClick={() => void voidInvoice(invoice)} disabled={Boolean(busyId)}>Void draft</button></>}
              {['issued', 'partially_paid', 'overdue'].includes(invoice.status) && <button className="button button-secondary button-small" type="button" onClick={() => openReceipt(invoice)} disabled={Boolean(busyId)}><ArrowDownLeft size={14} /> Record receipt</button>}
              {invoice.status === 'paid' && <span className="ar-paid-note"><CheckCircle2 size={14} /> Fully settled</span>}
            </div>
          </article>)}
        </div>}
      </section>

      {printInvoice&&<div className="invoice-paper-dialog-backdrop" role="presentation" onMouseDown={event=>{if(event.target===event.currentTarget)setPrintInvoice(null)}}>
        <section className="invoice-paper-dialog" role="dialog" aria-modal="true" aria-label={'Invoice '+printInvoice.invoiceNumber}>
          <div className="invoice-paper-actions"><button type="button" className="button button-secondary" onClick={()=>setPrintInvoice(null)}>Close</button>
            <button type="button" className="button button-primary" onClick={()=>window.print()}><Printer size={15}/> Print / save PDF</button></div>
          <InvoiceDocument invoice={printInvoice} businessName={workspace.businessName} currency={workspace.currency}/>
        </section>
      </div>}
      {selectedInvoice && <form className="ar-receipt-form"  onSubmit={(event) => void recordReceipt(event)}>
        <div className="ar-form-heading"><div><span className="eyebrow eyebrow-blue">STEP 3</span><h4>Record customer receipt</h4><p>{selectedInvoice.invoiceNumber} · {selectedInvoice.customerName} · Balance {money(selectedInvoice.balanceDueMinor, workspace.currency)}</p></div><button type="button" className="button button-secondary button-small" onClick={() => { setSelectedInvoice(null); setReceiptIdempotencyKey(''); }}>Cancel</button></div>
        <div className="ar-form-grid">
          <label className="field-label">Payment date<input required type="date" value={paymentDate} onChange={(event) => setPaymentDate(event.target.value)} /></label>
          <label className="field-label">Amount ({workspace.currency})<input required type="number" min="0.01" step={workspace.currency === 'UGX' ? '1' : '0.01'} max={asMajor(selectedInvoice.balanceDueMinor, workspace.currency)} value={paymentAmount} onChange={(event) => setPaymentAmount(event.target.value)} /></label>
          <label className="field-label">Payment method<select required value={paymentMethod} onChange={(event) => setPaymentMethod(event.target.value)}><option value="cash">Cash</option><option value="mtn_momo">MTN Mobile Money (recorded)</option><option value="airtel_money">Airtel Money (recorded)</option><option value="bank_transfer">Bank transfer (recorded)</option><option value="card_recorded">Card (recorded)</option><option value="other">Other</option></select></label>
          <label className="field-label">Reference (optional)<input value={paymentReference} onChange={(event) => setPaymentReference(event.target.value)} placeholder="Bank / mobile money reference" /></label>
        </div>
        <div className="ar-form-note">The amount is allocated directly to this invoice. For this increment, each receipt must be fully allocated; cash advances and unallocated customer credits will be added in a later phase.</div>
        <div className="ar-form-actions"><button className="button button-primary" type="submit" disabled={Boolean(busyId)}>{busyId === selectedInvoice.id ? 'Recording…' : 'Record and allocate receipt'} <ArrowDownLeft size={15} /></button></div>
      </form>}

      <section className="ar-section">
        <div className="ar-section-heading"><div><span className="eyebrow eyebrow-blue">RECONCILIATION</span><h4>Customer receipt register</h4><p>Includes receipts entered here and customer payments entered from the existing sales screen after an invoice is issued.</p></div><span className="ar-count">{receiptsQuery.isError?'Unavailable':receipts.length+' receipts'}</span></div>
        {receiptsQuery.isError ? <div className="inline-error">Could not load customer receipts. {receiptsQuery.error instanceof Error ? receiptsQuery.error.message : ''}</div> : receipts.length === 0 ? <div className="ar-empty">Receipts allocated to issued invoices will appear here.</div> : <div className="ar-receipt-list">
          {receipts.map((receipt) => <article className="ar-receipt-row" key={receipt.id}><div><strong>{receipt.receiptNumber}</strong><span>{receipt.customerName}</span><small>{receipt.paymentDate} · {receipt.method.replace(/_/g, ' ')}</small></div><div className="ar-receipt-allocation">{receipt.allocations.map((allocation) => <small key={allocation.invoiceId}>{allocation.invoiceNumber}</small>)}</div><strong>{money(receipt.amountMinor, workspace.currency)}</strong></article>)}
        </div>}
      </section>

      <div className="ar-tax-note"><AlertCircle size={16} /><span>These business invoices are not official URA EFRIS documents. When your business must issue an EFRIS invoice, also provide the valid URA document. Invoice totals preserve the original completed sale.</span></div>
    </section>
  );
}
