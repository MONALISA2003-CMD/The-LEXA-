/** The only source of electronics wizard dimensions is the published V2 catalogue. */
import {ELECTRONICS_V2_CONTRACT} from './electronics-catalogue-v2.generated';
import type {V2Family,V2Field} from './electronicsFamilyTypes';
export type WizardCategory={catalogCode?:string|null};
export function familyForCategory(category:WizardCategory|null|undefined):V2Family|null {
 const node=ELECTRONICS_V2_CONTRACT.nodes.find(n=>n.code===category?.catalogCode);
 const family=node?.familyCode?ELECTRONICS_V2_CONTRACT.families.find(f=>f.code===node.familyCode):null;
 return family?{...family,enabled:true}:null;
}
export function makeWizardFields(family:V2Family):readonly V2Field[]{return family.fields;}
export function validateWizardVariants(rows:ReadonlyArray<{sku:string;barcode?:string;gtin?:string}>,existing:ReadonlyArray<{sku:string;barcode?:string|null;gtin?:string|null}>):string[]{
 const errors:string[]=[],seen=new Set(existing.map(r=>r.sku.trim().toUpperCase())),codes=new Set(existing.flatMap(r=>[r.barcode,r.gtin].filter((x):x is string=>Boolean(x)).map(x=>x.toUpperCase())));
 for(const row of rows){const sku=row.sku.trim().toUpperCase();if(!sku||seen.has(sku))errors.push(`Duplicate or missing SKU: ${row.sku}`);seen.add(sku);
  for(const value of [row.barcode,row.gtin]){if(!value)continue;const code=value.trim().toUpperCase();if(codes.has(code))errors.push(`Repeated barcode or GTIN: ${code}`);codes.add(code);}
  if(row.gtin&&!/^(?:\d{8}|\d{12}|\d{13}|\d{14})$/.test(row.gtin))errors.push(`Invalid GTIN: ${row.gtin}`);
 }
 return errors;
}
