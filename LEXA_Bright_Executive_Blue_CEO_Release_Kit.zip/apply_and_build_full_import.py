#!/usr/bin/env python3
"""Safely apply the Bright Executive Blue patch to a local LEXA source clone,
then make a COMPLETE canonical archive for the existing GitHub importer.

Usage:
  python3 apply_and_build_full_import.py /path/to/The-LEXA- \
    --output /path/to/LEXA_BRIGHT_EXECUTIVE_FULL_IMPORT.zip

Important: NEVER upload this patch bundle as the root-level source import ZIP.
The GitHub workflow deletes and replaces the original source tree; only the
complete generated FULL_IMPORT archive is acceptable input to that workflow.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

EXPECTED_BASELINE = '052f265c71c284b45e9b84acee6b556a345f9f67'
ALLOWED_ROOTS = {'backend', 'lexa-frontend', 'docs', 'scripts'}
ALLOWED_ROOT_FILES = {
    '.dockerignore', '.gitignore', '.nvmrc', 'README.md',
    'REPOSITORY_LAYOUT_MANIFEST.json', 'render.yaml', 'LICENSE', 'LICENSE.md',
    'NOTICE', 'SECURITY.md', 'CODEOWNERS', '.gitattributes', '.editorconfig',
    '.prettierrc', '.prettierignore',
}
REQUIRED = {
    'README.md', 'render.yaml', 'REPOSITORY_LAYOUT_MANIFEST.json',
    'backend/package.json', 'backend/Dockerfile', 'backend/prisma/schema.prisma',
    'lexa-frontend/package.json', 'lexa-frontend/vercel.json',
    'scripts/clean_repository.py', 'scripts/validate_repository.py',
    'docs/architecture/backend-architecture.md',
    'docs/deployment/deployment-guide.md', 'docs/operations/runbooks/README.md',
}
FORBIDDEN_PARTS = {
    '.git', '.github', 'node_modules', 'dist', 'coverage', '.vercel',
    '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.turbo',
}
SKIP_TOP = {'.DS_Store'}


def replace_once(source: str, before: str, after: str, name: str) -> str:
    if after in source and before not in source:
        return source  # Idempotent without double-writing code.
    count = source.count(before)
    if count != 1:
        raise RuntimeError(f'{name}: expected 1 known insertion point; found {count}. Source may have changed.')
    return source.replace(before, after, 1)


def patch_sources(root: Path) -> None:
    main = root / 'lexa-frontend/src/main.tsx'
    code = main.read_text(encoding='utf8')
    code = replace_once(
        code,
        "import './styles/business-setup.css';",
        "import './styles/business-setup.css';\nimport './styles/lexa-executive-premium.css';",
        str(main),
    )
    main.write_text(code, encoding='utf8')

    dashboard = root / 'lexa-frontend/src/modules/dashboard/DashboardPage.tsx'
    code = dashboard.read_text(encoding='utf8')
    code = replace_once(
        code,
        '<h2>Your business, <span>in focus.</span></h2>',
        '<h2>Your business <span>at a glance.</span></h2>',
        str(dashboard),
    )
    code = replace_once(
        code,
        'BUSINESS OVERVIEW <i />',
        "{accessQuery.data?.isOwner ? 'CEO EXECUTIVE OVERVIEW' : 'BUSINESS OVERVIEW'} <i />",
        str(dashboard),
    )
    code = replace_once(
        code,
        'A decision-ready view of sales, stock, exceptions and day-to-day activity.',
        'Your verified performance, important exceptions and next actions in one place.',
        str(dashboard),
    )
    dashboard.write_text(code, encoding='utf8')

    shell = root / 'lexa-frontend/src/app/layouts/AppShell.tsx'
    code = shell.read_text(encoding='utf8')
    code = replace_once(
        code,
        '<div className="user-avatar" aria-label="Workspace operator">L</div>',
        '<div className="user-avatar" aria-label={isOwner ? "CEO account" : "Team member account"}>{isOwner ? "CEO" : "TM"}</div>',
        str(shell),
    )
    shell.write_text(code, encoding='utf8')

    readme = root / 'README.md'
    text = readme.read_text(encoding='utf8')
    heading = '## Bright Executive Blue CEO release — 3 November 2026'
    if heading not in text:
        text += '\n' + heading + '\n\n' + (
            'The bright executive design polishes Overview, My Business, owner-only '
            'team administration, navigation and shared card styles. It preserves '
            'verified financial data, tenant isolation, auth, schema and migrations. '
            'See `docs/release/bright-executive-ceo-2026-11-03.md`.\n'
        )
        readme.write_text(text, encoding='utf8')

    manifest_path = root / 'REPOSITORY_LAYOUT_MANIFEST.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf8'))
    manifest['version'] = '2026-11-03-bright-executive-blue'
    manifest['source_baseline'] = {
        'repository': 'MONALISA2003-CMD/The-LEXA-',
        'branch': 'main',
        'commit': EXPECTED_BASELINE,
        'note': 'Bright Executive Blue presentation release based on verified source commit; no production data or migration edits.',
        'archive_basis': 'Existing main source at 052f265 plus audited presentation files and CEO policy regression tests.',
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf8')


def validate_source(root: Path) -> None:
    if not root.is_dir():
        raise RuntimeError(f'LEXA source directory does not exist: {root}')
    missing = [item for item in sorted(REQUIRED) if not (root / item).is_file()]
    if missing:
        raise RuntimeError('Source is not a complete LEXA checkout. Missing: ' + ', '.join(missing))
    repo = root / '.git'
    if repo.exists():
        try:
            result = subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD'],
                                    text=True, capture_output=True, check=True)
        except (OSError, subprocess.CalledProcessError) as exc:
            raise RuntimeError(f'Cannot identify checkout revision: {exc}') from exc
        head = result.stdout.strip()
        if head != EXPECTED_BASELINE:
            raise RuntimeError(f'Source moved: expected {EXPECTED_BASELINE}, found {head}. '
                               'Do not apply this release blindly to a newer commit.')
        status = subprocess.run(['git', '-C', str(root), 'status', '--porcelain'],
                                text=True, capture_output=True, check=True).stdout
        if status.strip():
            raise RuntimeError('Source checkout has uncommitted changes. Use a clean clone at the pinned commit.')
    else:
        print('NOTICE: Source has no .git; validating required layout and known code anchors only.', file=sys.stderr)


def copy_source(source: Path, dest: Path) -> None:
    for item in source.iterdir():
        if item.name in SKIP_TOP:
            continue
        if item.is_symlink():
            raise RuntimeError(f'Symlink is not allowed: {item}')
        if item.is_dir():
            if item.name not in ALLOWED_ROOTS:
                continue
            shutil.copytree(item, dest / item.name, symlinks=True, ignore=shutil.ignore_patterns(
                '.git', '.github', 'node_modules', 'dist', 'coverage', '.vercel',
                '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.turbo',
                '*.zip', '*.pyc', '.env', '.env.*.local',
            ))
        elif item.name in ALLOWED_ROOT_FILES:
            shutil.copy2(item, dest / item.name)


def install_overlay(bundle: Path, dest: Path) -> None:
    overlay = bundle / 'overlay'
    if not overlay.is_dir():
        raise RuntimeError('Patch overlay/ directory is missing.')
    for source in overlay.rglob('*'):
        if not source.is_file():
            continue
        relative = source.relative_to(overlay)
        if source.is_symlink() or '..' in relative.parts or relative.parts[0] not in ALLOWED_ROOTS:
            raise RuntimeError(f'Unsafe release file: {relative}')
        target = dest / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)


def build_zip(staged: Path, output: Path) -> int:
    found: set[str] = set()
    seen_casefold: set[str] = set()
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipf:
        for source in sorted(staged.rglob('*')):
            if source.is_dir():
                continue
            if source.is_symlink():
                raise RuntimeError(f'Symlinks are not allowed: {source}')
            relative = source.relative_to(staged)
            parts = relative.parts
            if any(p in FORBIDDEN_PARTS for p in parts):
                continue
            if any(p.startswith('.env') and p not in {'.env.example', '.env.worker.example'} for p in parts):
                continue
            if source.suffix.lower() in {'.zip', '.pyc'}:
                continue
            if len(parts) == 1 and parts[0] not in ALLOWED_ROOT_FILES:
                raise RuntimeError(f'Unexpected root file: {relative}')
            if len(parts) > 1 and parts[0] not in ALLOWED_ROOTS:
                raise RuntimeError(f'Unexpected directory: {relative}')
            if source.stat().st_size > 100 * 1024 * 1024:
                raise RuntimeError(f'File exceeds import limit: {relative}')
            name = relative.as_posix()
            if name.casefold() in seen_casefold:
                raise RuntimeError(f'Case-colliding ZIP filename: {name}')
            zipf.write(source, name)
            seen_casefold.add(name.casefold())
            found.add(name)
    missing = sorted(REQUIRED - found)
    if missing:
        output.unlink(missing_ok=True)
        raise RuntimeError('Cannot build incomplete import ZIP. Missing: ' + ', '.join(missing))
    packages = sorted(n for n in found if n.endswith('/package.json'))
    if packages != ['backend/package.json', 'lexa-frontend/package.json']:
        output.unlink(missing_ok=True)
        raise RuntimeError(f'Expected exactly two package manifests, found {packages}')
    with zipfile.ZipFile(output) as zipf:
        if zipf.testzip() is not None:
            output.unlink(missing_ok=True)
            raise RuntimeError('Corrupt generated ZIP')
    return len(found)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='Local, complete LEXA source checkout at the pinned commit')
    parser.add_argument('--output', type=Path, default=Path.cwd() / 'LEXA_BRIGHT_EXECUTIVE_FULL_IMPORT.zip')
    args = parser.parse_args()
    source = args.source.expanduser().resolve()
    output = args.output.expanduser().resolve()
    bundle = Path(__file__).resolve().parent
    if source == bundle or bundle.is_relative_to(source):
        raise RuntimeError('Keep the downloaded patch bundle outside the LEXA source checkout.')
    if output.is_relative_to(source):
        raise RuntimeError('Write the full import ZIP outside the source checkout.')
    validate_source(source)
    with tempfile.TemporaryDirectory(prefix='lexa-bright-executive-') as temp:
        staged = Path(temp)
        copy_source(source, staged)
        install_overlay(bundle, staged)
        patch_sources(staged)
        count = build_zip(staged, output)
    print(f'OK: {output} ({count} complete canonical source files; {output.stat().st_size:,} bytes)')
    print('Upload ONLY this FULL_IMPORT ZIP to the GitHub repository root to trigger the validated import workflow.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (RuntimeError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        raise SystemExit(1)
