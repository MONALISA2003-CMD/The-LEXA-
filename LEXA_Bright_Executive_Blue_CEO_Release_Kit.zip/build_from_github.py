#!/usr/bin/env python3
"""One-command builder for the verified LEXA full-source GitHub import ZIP.

Requires Git, Python 3.10+, and internet on your own computer or Codespace.
It only downloads source and creates an archive; it never pushes or deploys.

    python3 build_from_github.py
"""
from __future__ import annotations
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
URL = 'https://github.com/MONALISA2003-CMD/The-LEXA-.git'
OUTPUT = ROOT / 'LEXA_BRIGHT_EXECUTIVE_FULL_IMPORT.zip'


def main() -> int:
    if OUTPUT.exists():
        print(f'ERROR: {OUTPUT.name} exists; move/delete the old file first.', file=sys.stderr)
        return 1
    with tempfile.TemporaryDirectory(prefix='lexa-release-clone-') as temp:
        clone = Path(temp) / 'The-LEXA-'
        print('Downloading LEXA main into a disposable clean checkout…', flush=True)
        subprocess.run(['git', 'clone', '--quiet', '--branch', 'main', '--single-branch',
                        '--depth', '1', URL, str(clone)], check=True)
        subprocess.run([sys.executable, str(ROOT / 'apply_and_build_full_import.py'),
                        str(clone), '--output', str(OUTPUT)], check=True)
    print('Full import ZIP is ready. Upload THAT ZIP, not the downloaded patch bundle.')
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (subprocess.CalledProcessError, OSError) as exc:
        print(f'ERROR: Could not build complete ZIP: {exc}', file=sys.stderr)
        raise SystemExit(1)
