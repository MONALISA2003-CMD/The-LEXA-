"""Smoke tests for the PATCH-to-FULL_IMPORT builder; no network or production access."""
from __future__ import annotations
import importlib.util
from pathlib import Path
import json
import tempfile
import unittest
import zipfile

BUNDLE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('lexa_release', BUNDLE / 'apply_and_build_full_import.py')
release = importlib.util.module_from_spec(spec)
spec.loader.exec_module(release)

class ReleaseSafety(unittest.TestCase):
    def test_css_syntax_and_design_tokens(self):
        import tinycss2
        css = (BUNDLE / 'overlay/lexa-frontend/src/styles/lexa-executive-premium.css').read_text()
        rules = tinycss2.parse_stylesheet(css, skip_comments=True, skip_whitespace=True)
        self.assertFalse([r for r in rules if r.type == 'error'])
        for token in ('#f6f9ff', '#075cf5', '.modern-overview', '.my-business-page', '.team-access-workspace', 'prefers-reduced-motion'):
            self.assertIn(token, css.lower())
        self.assertNotIn('!important', css.split('/* Respect the existing optional dark theme')[0].replace('padding-bottom: 16px !important;', '').replace('transition: none !important; transform: none !important;', ''))

    def test_required_source_layout_and_no_unallowed_paths(self):
        self.assertEqual({'backend', 'lexa-frontend', 'docs', 'scripts'}, release.ALLOWED_ROOTS)
        for p in (BUNDLE / 'overlay').rglob('*'):
            if p.is_file():
                self.assertIn(p.relative_to(BUNDLE / 'overlay').parts[0], release.ALLOWED_ROOTS)

    def test_patches_are_exact_and_never_guess_on_newer_version(self):
        self.assertEqual(release.replace_once('abc', 'ab', 'AC', 'test'), 'ACc')
        with self.assertRaises(RuntimeError):
            release.replace_once('abc', 'X', 'Y', 'test')
        with self.assertRaises(RuntimeError):
            release.replace_once('aa', 'a', 'x', 'test')

    def test_can_build_complete_archive_from_clean_fixture(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / 'src'
            root.mkdir()
            for item in release.REQUIRED:
                target = root / item
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text('source file\n')
            (root / 'lexa-frontend/src').mkdir(parents=True, exist_ok=True)
            (root / 'lexa-frontend/src/main.tsx').write_text("import './styles/business-setup.css';\n")
            (root / 'lexa-frontend/src/modules/dashboard').mkdir(parents=True, exist_ok=True)
            (root / 'lexa-frontend/src/modules/dashboard/DashboardPage.tsx').write_text(
                '<h2>Your business, <span>in focus.</span></h2> BUSINESS OVERVIEW <i /> '
                'A decision-ready view of sales, stock, exceptions and day-to-day activity.')
            (root / 'lexa-frontend/src/app/layouts').mkdir(parents=True, exist_ok=True)
            (root / 'lexa-frontend/src/app/layouts/AppShell.tsx').write_text(
                '<div className="user-avatar" aria-label="Workspace operator">L</div>')
            (root / 'REPOSITORY_LAYOUT_MANIFEST.json').write_text(json.dumps({'source_baseline': {}}))
            (root / 'README.md').write_text('LEXA\n')
            (root / '.github/workflows').mkdir(parents=True, exist_ok=True)
            (root / '.github/workflows/do_not_copy.yml').write_text('protected!')
            (root / 'backend/.env').write_text('SECRET=do-not-copy')
            staged = Path(d) / 'stage'
            staged.mkdir()
            release.validate_source(root)
            release.copy_source(root, staged)
            release.install_overlay(BUNDLE, staged)
            release.patch_sources(staged)
            output = Path(d) / 'FULL_IMPORT.zip'
            count = release.build_zip(staged, output)
            self.assertGreater(count, 15)
            with zipfile.ZipFile(output) as z:
                self.assertFalse(any(n.startswith('.github/') for n in z.namelist()))
                self.assertNotIn('backend/.env', z.namelist())
                self.assertIn('lexa-frontend/src/styles/lexa-executive-premium.css', z.namelist())
                self.assertIn('backend/test/ceo-role-release-contract.test.mjs', z.namelist())
                self.assertIn('CEO EXECUTIVE OVERVIEW', z.read('lexa-frontend/src/modules/dashboard/DashboardPage.tsx').decode())
                self.assertIn("import './styles/lexa-executive-premium.css'", z.read('lexa-frontend/src/main.tsx').decode())
                self.assertIn('CEO / Owner', z.read('lexa-frontend/src/modules/workspace/WorkspacePage.tsx').decode())

if __name__ == '__main__':
    unittest.main()
